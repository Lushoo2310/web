<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // \App\Models\User::factory(10)->create();

        // \App\Models\User::factory()->create([
        //     'name' => 'Test User',
        //     'email' => 'test@example.com',
        // ]);
        $this->call(RolSeeder::class);
        $this->call(RelacionLaboralSeeder::class);
        $this->call(DedicacionSeeder::class);
        $this->call(TipoFormacionSeeder::class);
        $this->call(TipoProduccionSeeder::class);
        $this->call(TipoPeriodoSeeder::class);
        $this->call(RepositorioSeeder::class);
        $this->call(UsuarioSeeder::class);
    }
}
