<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class RepositorioSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $tabla = 'repositorio_art';
        DB::statement('SET FOREIGN_KEY_CHECKS = 0;');
        DB::table($tabla)->truncate();
        DB::statement('SET FOREIGN_KEY_CHECKS = 1;');
        DB::table($tabla)->insert([
            [
                'cod_repositorio_art' => 1,
                'nombre' => 'Web of Science'
            ],
            [
                'cod_repositorio_art' => 2,
                'nombre' => 'Scopus'
            ],
            [
                'cod_repositorio_art' => 3,
                'nombre' => 'SciELO'
            ],
            [
                'cod_repositorio_art' => 4,
                'nombre' => 'Google Scholar'
            ],
            [
                'cod_repositorio_art' => 5,
                'nombre' => 'Latindex'
            ],
            [
                'cod_repositorio_art' => 6,
                'nombre' => 'Dialnet'
            ],
            [
                'cod_repositorio_art' => 7,
                'nombre' => 'Otros Repositorios'
            ],
        ]);
    }
}
