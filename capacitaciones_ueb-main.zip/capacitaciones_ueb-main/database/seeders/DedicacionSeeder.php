<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DedicacionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $tabla = 'dedicaciones';
        DB::statement('SET FOREIGN_KEY_CHECKS = 0;');
        DB::table($tabla)->truncate();
        DB::statement('SET FOREIGN_KEY_CHECKS = 1;');
        DB::table($tabla)->insert([
            [
                'cod_dedicacion' => 1,
                'nombre' => 'Tiempo Completo'
            ],
            [
                'cod_dedicacion' => 2,
                'nombre' => 'Medio Tiempo'
            ],
            [
                'cod_dedicacion' => 3,
                'nombre' => 'Tiempo Parcial'
            ]
        ]);
    }
}
