<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class UsuarioSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $tabla = 'usuarios';
        DB::statement('SET FOREIGN_KEY_CHECKS = 0;');
        DB::table($tabla)->truncate();
        DB::statement('SET FOREIGN_KEY_CHECKS = 1;');
        DB::table($tabla)->insert([
            [
                'cod_user' => 1,
                'nombres' => 'Alexander Paul',
                'apellidos' => 'Luna Arteaga',
                'password' => bcrypt('admin'),
                'cedula' => '0202433918',
                'status' => 1,
                'email' => 'aluna@mailes.ueb.edu.ec',
                'cod_relacion_laboral' => 1,
                'cod_rol' => 1,
                'cod_dedicacion' => 1
            ],
            [
                'cod_user' => 2,
                'nombres' => 'Wilson Efrain',
                'apellidos' => 'Paredes Guano',
                'password' => bcrypt('admin'),
                'cedula' => '0250322666',
                'status' => '1',
                'email' => 'wiparedes@mailes.ueb.edu.ec',
                'cod_relacion_laboral' => 1,
                'cod_rol' => 1,
                'cod_dedicacion' => 1
            ]
        ]);
        $arrays = [

            ['0200799013', 'Carlos Alfredo', 'Gruezo Gonzalez', 'cgruezo@ueb.edu.ec', 'Personal Ocasional'],
            ['0200938504', 'Nancy Concepcion', 'Perez Gaibor', 'nperez@ueb.edu.ec', 'Personal Ocasional'],
            ['0201187200', 'Jefferson Napoleon', 'Naranjo Gaibor', 'jnaranjo@ueb.edu.ec', 'Personal Ocasional'],
            ['0201302858', 'Sandra Janeth', 'Paredes Jiménez', 'sparedes@ueb.edu.ec', 'Personal Ocasional'],
            ['0201321346', 'Danilo Renato', 'Valle Arellano', 'dvalle@ueb.edu.ec', 'Personal Ocasional'],
            ['0201416005', 'Germán Patricio', 'Sánchez Chávez', 'gsanchez@ueb.edu.ec', 'Personal Ocasional'],
            ['0201506672', 'Gina Jaqueline', 'Alarcón Quinato', 'agalarcon@ueb.edu.ec', 'Personal Ocasional'],
            ['0201541877', 'Carmita Galudth', 'Borja Borja', 'cborja@ueb.edu.ec', 'Personal Ocasional'],
            ['0201567203', 'Christian Fernando', 'Barragán Quizhpe', 'cbarragan@ueb.edu.ec', 'Personal Ocasional'],
            ['0201577756', 'Gabriela Paola', 'Carrasco Lara', 'gcarrasco@ueb.edu.ec', 'Personal Ocasional'],
            ['0201581196', 'Paola Estefania', 'Alban Trujillo', 'palban@ueb.edu.ec', 'Personal Ocasional'],
            ['0201618253', 'Galuth Irene', 'Garcia Camacho', 'ggarcia@ueb.edu.ec', 'Personal Ocasional'],
            ['0201697299', 'Patricia De Lourdes', 'Leon Monar', 'pleon@ueb.edu.ec', 'Personal Ocasional'],
            ['0201722238', 'Elsita Margoth', 'Chavez Garcia', 'emchavez@ueb.edu.ec', 'Personal Ocasional'],
            ['0201772092', 'Karina Johanna', 'Iza López', 'kiza@ueb.edu.ec', 'Personal Ocasional'],
            ['0201780798', 'Johana Guadalupe', 'Garcia Leon', 'jggarcia@ueb.edu.ec', 'Personal Ocasional'],
            ['0201819471', 'Ivan Marcelo', 'Yacchirema Taraguay', 'iyacchirema@ueb.edu.ec', 'Personal Ocasional'],
            ['0201851052', 'Jessica Ernestina', 'Duran Delgado', 'jessica.duran@ueb.edu.ec', 'Personal Ocasional'],
            ['0201861986', 'Clarita Vanessa', 'Gavilanez Cardenas', 'cgavilanez@ueb.edu.ec', 'Personal Ocasional'],
            ['0201932183', 'Verónica Tatiana', 'García García', 'vegarcia@ueb.edu.ec', 'Personal Ocasional'],
            ['0201957404', 'María Augusta', 'Ulloa Rivadeneira', 'maria.ulloa@ueb.edu.ec', 'Personal Ocasional'],
            ['0201991536', 'Rafael Alejandro', 'Sanchez Macias', 'rsanchez@ueb.edu.ec', 'Personal Ocasional'],
            ['0202021135', 'Jesús Antonio', 'Coloma Garófalo', 'jcoloma@ueb.edu.ec', 'Personal Ocasional'],
            ['0202026605', 'Miguel Angel', 'Lombeida Aguilar', 'milombeida@ueb.edu.ec', 'Personal Ocasional'],
            ['0202396495', 'Dayana Patricia', 'Aldaz León', 'daldaz@ueb.edu.ec', 'Personal Ocasional'],
            ['0400987764', 'Leonardo Ramiro', 'Cabezas Reinoso', 'leonardo.cabezas@ueb.edu.ec', 'Personal Ocasional'],
            ['0602028003', 'José Miguel', 'Ocaña Morales', 'jocana@ueb.edu.ec', 'Personal Ocasional'],
            ['0603036294', 'Jorge Renato', 'Cabezas Ramos', 'jcabezas@ueb.edu.ec', 'Personal Ocasional'],
            ['0603448416', 'Juan Pablo', 'Torres Cadena', 'jtorres@ueb.edu.ec', 'Personal Ocasional'],
            ['0604062711', 'Jessica Andrea', 'Barreto Bonilla', 'jbarreto@ueb.edu.ec', 'Personal Ocasional'],
            ['0604114348', 'Erika Nataly', 'Alvarado Ramos', 'enalvarado@ueb.edu.ec', 'Personal Ocasional'],
            ['0604182808', 'Aura Deysi', 'Anchundia Anchundia', 'aura.anchundia@ueb.edu.ec', 'Personal Ocasional'],
            ['0703129981', 'Eddy Stalin', 'Alvarado Pacheco', 'ealvarado@ueb.edu.ec', 'Personal Ocasional'],
            ['0907891113', 'Victor Vicente', 'Viteri Valle', 'vviteri@ueb.edu.ec', 'Personal Ocasional'],
            ['0920948536', 'Magdalena Iralda', 'Valero Camino', 'mvalero@ueb.edu.ec', 'Personal Ocasional'],
            ['1311691800', 'Martha Lissette', 'Zambrano Moreira', 'mzambrano@ueb.edu.ec', 'Personal Ocasional'],
            ['1710052661', 'Renato Estuardo', 'Paredes Cruz', 'rparedes@ueb.edu.ec', 'Personal Ocasional'],
            ['1719395731', 'Erika Priscila', 'Cahuasqui Molina', 'ecahuasqui@ueb.edu.ec', 'Personal Ocasional'],
            ['1803015484', 'Edgar Marcelo', 'Vilcacundo Chamorro', 'mvilcacundo@ueb.edu.ec', 'Personal Ocasional'],
            ['0200583250', 'Nelson Javier', 'Garcia Lopez', 'jgarcia@ueb.edu.ec', 'Personal Titular'],
            ['0200667335', 'Angel Mussoline', 'Garcia Del Pozo', 'agarcia@ueb.edu.ec', 'Personal Titular'],
            ['0200719243', 'Gorqui Elisalde', 'Vistín Mena', 'gvistin@ueb.edu.ec', 'Personal Titular'],
            ['0200724714', 'Marlon Alberto', 'Garcia Saltos', 'magarcia@ueb.edu.ec', 'Personal Titular'],
            ['0200732303', 'Fidel Alberto', 'Castro Berio', 'fcastro@ueb.edu.ec', 'Personal Titular'],
            ['0200798254', 'Aida Isabel', 'Jaya Escobar', 'ajaya@ueb.edu.ec', 'Personal Titular'],
            ['0200802932', 'Luis Ricardo', 'Villacis Monar', 'lvillacis@ueb.edu.ec', 'Personal Titular'],
            ['0200805877', 'Mario Heriberto', 'Sanchez Quiroz', 'msanchez@ueb.edu.ec', 'Personal Titular'],
            ['0200834562', 'Jorge Estuardo', 'Goyes Noboa', 'jgoyes@ueb.edu.ec', 'Personal Titular'],
            ['0200856557', 'Rodrigo Humberto', 'Del Pozo Durango', 'rdelpozo@ueb.edu.ec', 'Personal Titular'],
            ['0200858702', 'Rene Mesias', 'Villacres Borja', 'rvillacres@ueb.edu.ec', 'Personal Titular'],
            ['0200886844', 'Mario Enrique', 'Escobar Gortaire', 'mescobar@ueb.edu.ec', 'Personal Titular'],
            ['0200911568', 'Manola Lorena', 'Gonzalez Najera', 'lgonzalez@ueb.edu.ec', 'Personal Titular'],
            ['0200967461', 'Sergio Enrique', 'Fierro Barragan', 'sefierro@ueb.edu.ec', 'Personal Titular'],
            ['0200970994', 'Ramiro Fernando', 'Jaramillo Villafuerte', 'rjaramillo@ueb.edu.ec', 'Personal Titular'],
            ['0201032315', 'Victor Hugo', 'Quizhpe Baculima', 'vquizhpe@ueb.edu.ec', 'Personal Titular'],
            ['0201080736', 'Fharab De Lourdes', 'Hernandez Aguiar', 'fhernandez@ueb.edu.ec', 'Personal Titular'],
            ['0201089380', 'Pilar Janeth', 'Chavez Chacan', 'pchavez@ueb.edu.ec', 'Personal Titular'],
            ['0201124823', 'Wilter Rodolfo', 'Camacho Arellano', 'wcamacho@ueb.edu.ec', 'Personal Titular'],
            ['0201176062', 'Edgar Patricio', 'Rivadeneira Ramos', 'eribaden@ueb.edu.ec', 'Personal Titular'],
            ['0201213584', 'Maria Fernanda', 'Quintana Saltos', 'mquintana@ueb.edu.ec', 'Personal Titular'],
            ['0201351046', 'Ernesto Paul', 'Zavala Cardenas', 'ezavala@ueb.edu.ec', 'Personal Titular'],
            ['0201359965', 'Maricela Araceli', 'Espin Morejón', 'mespin@ueb.edu.ec', 'Personal Titular'],
            ['0201445368', 'Dolly Silvana', 'Del Salto Davila', 'ddelsalto@ueb.edu.ec', 'Personal Titular'],
            ['0201463627', 'Carlos Oswaldo', 'Peña Guaman', 'cpena@ueb.edu.ec', 'Personal Titular'],
            ['0201463841', 'Fatima Del Rocio', 'Nuñez Aguiar', 'fnunez@ueb.edu.ec', 'Personal Titular'],
            ['0201572963', 'Charles Paul', 'Viscarra Armijos', 'chviscarra@ueb.edu.ec', 'Personal Titular'],
            ['0201666302', 'Veronica Del Carmen', 'Arguello Delgado', 'varguello@ueb.edu.ec', 'Personal Titular'],
            ['0201929833', 'Alexandra Maribel', 'Arguello Pazmiño', 'amarguello@ueb.edu.ec', 'Personal Titular'],
            ['0601830524', 'Carlos Enrique', 'Taco Padilla', 'ctaco@ueb.edu.ec', 'Personal Titular'],
            ['0602039588', 'Edelmira Lila', 'Guevara Iñiguez', 'eguevara@ueb.edu.ec', 'Personal Titular'],
            ['0602281941', 'Henry Fernando', 'Vallejo Ballesteros', 'hvallejo@ueb.edu.ec', 'Personal Titular'],
            ['0602571572', 'Danilo Geovanny', 'Barreno Naranjo', 'dbarreno@ueb.edu.ec', 'Personal Titular'],
            ['0602724049', 'Edgar Henry', 'Alban Yanez', 'halban@ueb.edu.ec', 'Personal Titular'],
            ['0602928707', 'Danilo Eduardo', 'Villarroel Silva', 'dvillarroel@ueb.edu.ec', 'Personal Titular'],
            ['0602934465', 'Willian Marco', 'Samaniego Erazo', 'wsamaniego@ueb.edu.ec', 'Personal Titular'],
            ['0603021395', 'Darwin Paul', 'Carrion Buenaño', 'dcarrion@ueb.edu.ec', 'Personal Titular'],
            ['0603602400', 'Oscar Paul', 'Tanqueño Colcha', 'otanqueno@ueb.edu.ec', 'Personal Titular'],
            ['0909086787', 'Ruth Cecibelt', 'Cedeño Alvarez', 'rcedeno@ueb.edu.ec', 'Personal Titular'],
            ['1102742143', 'Jose Vladimir', 'Guarnizo Delgado', 'jguarnizo@ueb.edu.ec', 'Personal Titular'],
            ['1304701939', 'Gina Marisol', 'Acebo Del Valle', 'gacebo@ueb.edu.ec', 'Personal Titular'],
            ['1705114948', 'Juan Manuel', 'Galarza Schoenfeld', 'jgalarza@ueb.edu.ec', 'Personal Titular'],
            ['1705642021', 'Salomón Rodrigo', 'Cargua Suarez', 'scargua@ueb.edu.ec', 'Personal Titular'],
            ['1715314132', 'Kléver Renato', 'Romero Quiroga', 'rromero@ueb.edu.ec', 'Personal Titular'],
            ['1716764731', 'Veronica Maribel', 'Arcos Bosquez', 'varcos@ueb.edu.ec', 'Personal Titular'],
            ['1801682095', 'Segundo Rafael', 'Medina Velasco', 'smedina@ueb.edu.ec', 'Personal Titular'],
            ['1801894146', 'Marcelo Gustavo', 'Barriga Tamay', 'mbarriga@ueb.edu.ec', 'Personal Titular'],
            ['1802628568', 'Monica Elizabeth', 'Bonilla Manobanda', 'mbonilla@ueb.edu.ec', 'Personal Titular'],
        ];

        foreach ($arrays as list($ci, $name, $apelli, $email, $r_labo)) {
            if ($r_labo == 'Personal Ocacional') {
                $rela = 2;
            } else {
                $rela = 1;
            }
            $dedicacion = 1;

            DB::table($tabla)->insert([
                'cedula' => $ci,
                'nombres' => $name,
                'apellidos' => $apelli,
                'email' => $email,
                'password' => bcrypt($ci),
                'cod_relacion_laboral' => $rela,
                'status' => 1,
                'cod_rol' => 3,
                'cod_dedicacion' => $dedicacion
            ]);
        }
    }
}
