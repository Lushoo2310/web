<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class TipoProduccionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $tabla = 'tipo_producciones';
        DB::statement('SET FOREIGN_KEY_CHECKS = 0;');
        DB::table($tabla)->truncate();
        DB::statement('SET FOREIGN_KEY_CHECKS = 1;');
        DB::table($tabla)->insert([
            [
                'cod_tipo' => 1,
                'nombre' => 'Artículo'
            ],
            [
                'cod_tipo' => 2,
                'nombre' => 'Libro/Capítulo'
            ],
            [
                'cod_tipo' => 3,
                'nombre' => 'Ponencia (Seminario/Congreso)'
            ]
        ]);
    }
}
