<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('usuarios', function (Blueprint $table) {
            $table->bigIncrements('cod_user');
            $table->string('nombres');
            $table->string('apellidos');
            $table->string('cedula', 10)->nullable()->unique();
            $table->string('email')->unique();
            $table->integer('status');
            $table->unsignedBigInteger('cod_rol');
            $table->unsignedBigInteger('cod_relacion_laboral');
            $table->unsignedBigInteger('cod_dedicacion');
            $table->foreign('cod_rol')
                ->references('cod_rol')->on('roles')->cascadeOnUpdate();
            $table->timestamp('email_verified_at')->nullable();
            $table->foreign('cod_relacion_laboral')
                ->references('cod_relacion_laboral')->on('relaciones_laborales')->cascadeOnUpdate();
            $table->foreign('cod_dedicacion')
                ->references('cod_dedicacion')->on('dedicaciones')->cascadeOnUpdate();
            $table->string('password');
            $table->rememberToken();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('usuarios');
    }
};
