<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('producciones', function (Blueprint $table) {
            $table->bigIncrements('cod_produccion');
            $table->string('titulo');
            $table->string('nombre');
            $table->string('pais_revista')->nullable();
            $table->string('editorial')->nullable();
            $table->date('fecha_publicacion_art')->nullable();
            $table->date('fecha_publicacion_lib')->nullable();
            $table->string('indexacion')->nullable();
            $table->date('fecha_evento')->nullable();
            $table->string('isbn')->nullable();
            $table->string('issn')->nullable();
            $table->string('pais_evento')->nullable();
            $table->string('doi')->nullable();
            $table->string('enlace_art')->nullable();
            $table->string('enlace_lib')->nullable();
            $table->string('modalidad')->nullable();
            $table->string('sjr')->nullable();
            $table->string('jcr')->nullable();
            $table->string('otro_repositorio')->nullable();
            $table->unsignedBigInteger('cod_tipo');
            $table->foreign('cod_tipo')
                ->references('cod_tipo')->on('tipo_producciones')->cascadeOnUpdate();
            $table->unsignedBigInteger('cod_repositorio_art')->nullable();
            $table->foreign('cod_repositorio_art')
                ->references('cod_repositorio_art')->on('repositorio_art')->cascadeOnUpdate();
            $table->unsignedBigInteger('cod_user');
            $table->foreign('cod_user')
                ->references('cod_user')->on('usuarios')->cascadeOnUpdate();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('producciones');
    }
};
