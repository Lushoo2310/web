<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('asig_academicas', function (Blueprint $table) {
            $table->bigIncrements('cod_asig_academica');
            $table->string('carrera');
            $table->integer('num_materias')->nullable();
            $table->integer('num_materias_m_s')->nullable();
            $table->integer('num_materias_m_n')->nullable();
            $table->integer('num_materias_d_s')->nullable();
            $table->integer('num_materias_d_n')->nullable();
            $table->unsignedBigInteger('cod_p_academico');
            $table->foreign('cod_p_academico')
                ->references('cod_p_academico')->on('periodos_academicos')->cascadeOnUpdate();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('asig_academicas');
    }
};
