<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('formaciones', function (Blueprint $table) {
            $table->bigIncrements('cod_formacion');
            $table->string('registro', 150);
            $table->string('titulo', 150);
            $table->unsignedBigInteger('cod_tipo');
            $table->unsignedBigInteger('cod_user');
            $table->foreign('cod_tipo')
                ->references('cod_tipo')->on('tipo_formaciones')->cascadeOnUpdate();
            $table->foreign('cod_user')
                ->references('cod_user')->on('usuarios')->cascadeOnUpdate();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('formaciones');
    }
};
