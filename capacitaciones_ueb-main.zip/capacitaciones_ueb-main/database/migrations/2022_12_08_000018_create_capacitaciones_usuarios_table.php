<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('capacitaciones_usuarios', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->foreignId('cod_capacitacion')->nullable()->constrained('capacitaciones', 'cod_capacitacion')
                ->cascadeOnUpdate()->nullOnDelete();
            $table->foreignId('cod_user')->nullable()->constrained('usuarios', 'cod_user')
                ->cascadeOnUpdate()->nullOnDelete();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('capacitaciones_usuarios');
    }
};
