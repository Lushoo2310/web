<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('capacitaciones', function (Blueprint $table) {
            $table->bigIncrements('cod_capacitacion');
            $table->string('evento', 150);
            $table->string('tipo_evento', 250)->nullable();
            $table->date('fecha_evento');
            $table->string('institucion_organizadora', 250)->nullable();
            $table->string('pais');
            $table->string('modalidad', 50);
            $table->string('num_horas')->nullable();
            $table->unsignedBigInteger('cod_user');
            $table->foreign('cod_user')
                ->references('cod_user')->on('usuarios')->cascadeOnUpdate();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('capacitaciones');
    }
};
