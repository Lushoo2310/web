<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('periodos_academicos', function (Blueprint $table) {
            $table->bigIncrements('cod_p_academico');
            $table->date('fecha_inicio');
            $table->date('fecha_fin');
            $table->unsignedBigInteger('cod_user');
            $table->foreign('cod_user')
                ->references('cod_user')->on('usuarios')->cascadeOnUpdate();
            $table->unsignedBigInteger('cod_tipo_p');
            $table->foreign('cod_tipo_p')
                ->references('cod_tipo_p')->on('tipo_periodos')->cascadeOnUpdate();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('periodos_academicos');
    }
};
