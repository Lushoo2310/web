<?php

use App\Http\Controllers\Auth\AuthenticatedSessionController;
use App\Http\Controllers\CapacitacionController;
use App\Http\Controllers\FormacionController;
use App\Http\Controllers\PeriodoAcademicoController;
use App\Http\Controllers\ProduccionController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\AsigAcademicaController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('', function () {
    // return view('welcome');
    return redirect()->route('login');
});

//Route::middleware('guest')->group(function () {
// Route::get('/', [AuthenticatedSessionController::class, 'create'])
//     ->name('login');
// //});

// Route::get('/', [AuthenticatedSessionController::class, 'create'])
//     ->name('login');


Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

//Rutas de Capacitaciones
Route::middleware(['auth'])->group(function () {
    Route::get('/capacitaciones/pdf', [CapacitacionController::class, 'pdf'])->name('capacitaciones.pdf');
    Route::get('/capacitaciones/create', [CapacitacionController::class, 'create'])->name('capacitaciones.create');
    Route::get('/capacitaciones/{capacitacion}/edit', [CapacitacionController::class, 'edit'])->name('capacitaciones.edit');
    Route::put('/capacitaciones/{capacitacion}/', [CapacitacionController::class, 'update'])->name('capacitaciones.update');
    Route::get('/capacitaciones/{capacitacion}/', [CapacitacionController::class, 'show'])->name('capacitaciones.show');
    Route::post('/capacitaciones/', [CapacitacionController::class, 'store'])->name('capacitaciones.store');
    Route::delete('/capacitaciones/{capacitacion}/', [CapacitacionController::class, 'destroy'])->name('capacitaciones.destroy');
    Route::get('/capacitaciones', [CapacitacionController::class, 'index'])->name('capacitaciones.index');
});

//Rutas de Periodos Academicos
Route::middleware(['auth'])->group(function () {
    Route::get('/periodos/create', [PeriodoAcademicoController::class, 'create'])->name('periodos.create');
    Route::get('/periodos/{periodo}/edit', [PeriodoAcademicoController::class, 'edit'])->name('periodos.edit');
    Route::put('/periodos/{periodo}/', [PeriodoAcademicoController::class, 'update'])->name('periodos.update');
    Route::get('/periodos/{periodo}/', [PeriodoAcademicoController::class, 'show'])->name('periodos.show');
    Route::post('/periodos/', [PeriodoAcademicoController::class, 'store'])->name('periodos.store');
    Route::delete('/periodos/{periodo}/', [PeriodoAcademicoController::class, 'destroy'])->name('periodos.destroy');
    Route::get('/periodos', [PeriodoAcademicoController::class, 'index'])->name('periodos.index');
});

//Rutas Asignacion Academica
Route::middleware(['auth'])->group(function () {
    Route::get('/asigacademica/create', [AsigAcademicaController::class, 'create'])->name('asigacademica.create');
    Route::get('/asigacademica/{asigacademica}/edit', [AsigAcademicaController::class, 'edit'])->name('asigacademica.edit');
    Route::put('/asigacademica/{asigacademica}/', [AsigAcademicaController::class, 'update'])->name('asigacademica.update');
    Route::get('/asigacademica/{asigacademica}/', [AsigAcademicaController::class, 'show'])->name('asigacademica.show');
    Route::post('/asigacademica/', [AsigAcademicaController::class, 'store'])->name('asigacademica.store');
    Route::delete('/asigacademica/{asigacademica}/', [AsigAcademicaController::class, 'destroy'])->name('asigacademica.destroy');
    Route::get('/asigacademica', [AsigAcademicaController::class, 'index'])->name('asigacademica.index');
});


//Rutas Produccion Academica
Route::middleware(['auth'])->group(function () {
    Route::get('/produccion/create', [ProduccionController::class, 'create'])->name('produccion.create');
    Route::get('/produccion/{produccion}/edit', [ProduccionController::class, 'edit'])->name('produccion.edit');
    Route::put('/produccion/{produccion}/', [ProduccionController::class, 'update'])->name('produccion.update');
    Route::get('/produccion/{produccion}/', [ProduccionController::class, 'show'])->name('produccion.show');
    Route::post('/produccion/', [ProduccionController::class, 'store'])->name('produccion.store');
    Route::delete('/produccion/{produccion}/', [ProduccionController::class, 'destroy'])->name('produccion.destroy');
    Route::get('/produccion', [ProduccionController::class, 'index'])->name('produccion.index');
});

//Rutas Formacion Academico
Route::middleware(['auth'])->group(function () {
    Route::get('/formacion/create', [FormacionController::class, 'create'])->name('formacion.create');
    Route::get('/formacion/{formacion}/edit', [FormacionController::class, 'edit'])->name('formacion.edit');
    Route::put('/formacion/{formacion}/', [FormacionController::class, 'update'])->name('formacion.update');
    Route::get('/formacion/{formacion}/', [FormacionController::class, 'show'])->name('formacion.show');
    Route::post('/formacion/', [FormacionController::class, 'store'])->name('formacion.store');
    Route::delete('/formacion/{formacion}/', [FormacionController::class, 'destroy'])->name('formacion.destroy');
    Route::get('/formacion', [FormacionController::class, 'index'])->name('formacion.index');
});




require __DIR__ . '/auth.php';
