<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TipoFormacion extends Model
{
    use HasFactory;
    protected $table = 'tipo_formaciones';
    protected $primaryKey = 'cod_tipo';
    protected $fillable = [
        'cod_tipo',
        'nombre'
    ];
    protected $hidden = [
        'created_at',
        'updated_at'
    ];
    public function obtenerTipoFormacion()
    {
        return TipoFormacion::all();
    }
    public function obtenerTipoFormacionId($id)
    {
        return TipoFormacion::find($id);
    }
}
