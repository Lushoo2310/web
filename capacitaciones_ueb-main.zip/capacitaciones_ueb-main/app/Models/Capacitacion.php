<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Capacitacion extends Model
{
    use HasFactory;
    protected $table = 'capacitaciones';
    protected $primaryKey = 'cod_capacitacion';
    protected $fillable = [
        'cod_capacitacion',
        'evento',
        'cod_user',
        'tipo_evento',
        'fecha_evento',
        'cod_p_academico',
        'institucion_organizadora',
        'num_horas',
        'pais',
        'modalidad',
        'cod_tipo_p'
    ];
    protected $hidden = [
        'created_at',
        'updated_at'
    ];
    public function usuarios()
    {
        return $this->belongsToMany(User::class, 'capacitaciones:user');
    }
}
