<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RepositorioArt extends Model
{
    use HasFactory;
    protected $table = 'repositorio_art';
    protected $primaryKey = 'cod_repositorio_art';
    protected $fillable = [
        'cod_repositorio_art',
        'nombre'
    ];
    protected $hidden = [
        'created_at',
        'updated_at'
    ];
    protected function obtenerRepositorioArt()
    {
        return RepositorioArt::all();
    }
    public function obtenerRepositorioArtId($id)
    {
        return RepositorioArt::find($id);
    }
    // public function produccionAcademica()
    // {
    //     return $this->hasMany(Produccion::class, 'cod_repositorio_art', 'cod_repositorio_art');
    // }
}
