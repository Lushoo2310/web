<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Formacion extends Model
{
    use HasFactory;
    protected $table = 'formaciones';
    protected $primaryKey = 'cod_formacion';
    protected $fillable = [
        'cod_formacion',
        'registro',
        'titulo',
        'cod_tipo',
        'cod_user'
    ];
    protected $hidden = [
        'created_at',
        'updated_at'
    ];

    public function usuarios()
    {
        return $this->belongsToMany(User::class, 'cod_user', 'cod_user');
    }

    public function TipoFormacion()
    {
        return $this->belongsTo(TipoFormacion::class, 'cod_tipo', 'cod_tipo');
    }
}
