<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Produccion extends Model
{
    use HasFactory;
    protected $table = 'producciones';
    protected $primaryKey = 'cod_produccion';
    protected $fillable = [
        'cod_produccion',
        'titulo',
        'nombre',
        'pais_revista',
        'editorial',
        'fecha_publicacion_art',
        'fecha_publicacion_lib',
        'indexacion',
        'fecha_evento',
        'isbn',
        'issn',
        'pais_evento',
        'doi',
        'enlace_art',
        'enlace_lib',
        'modalidad',
        'sjr',
        'jcr',
        'otro_repositorio',
        'cod_tipo',
        'cod_repositorio_art',
        'cod_user',
    ];
    protected $hidden = [
        'created_at',
        'updated_at'
    ];

    public function usuarios()
    {
        // return $this->belongsToMany(User::class, 'produccion_user', 'cod_produccion', 'cod_user');
        return $this->belongsToMany(User::class, 'cod_user', 'cod_user');
    }

    public function TipoProduccion()
    {
        return $this->belongsTo(TipoProduccion::class, 'cod_tipo', 'cod_tipo');
    }

    public function RepositorioArt()
    {
        return $this->belongsTo(RepositorioArt::class, 'cod_repositorio_art', 'cod_repositorio_art');
    }
}
