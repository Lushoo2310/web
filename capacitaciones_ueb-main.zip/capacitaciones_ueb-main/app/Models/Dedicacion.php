<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Dedicacion extends Model
{
    use HasFactory;
    protected $table = 'dedicaciones';
    protected $primarykey = 'cod_dedicacion';
    protected $fillable = [
        'cod_dedicacion',
        'tiempo'
    ];
    protected $hidden = [
        'created_at',
        'updated_at'
    ];
    public function obtenerDedicaciones()
    {
        return dedicacion::all();
    }
    public function obtenerDedicacionId($id)
    {
        return dedicacion::find($id);
    }
}
