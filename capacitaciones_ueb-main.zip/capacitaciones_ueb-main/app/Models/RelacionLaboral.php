<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RelacionLaboral extends Model
{
    use HasFactory;
    protected $table = 'relaciones_laborales';
    protected $primarykey = 'cod_relacion_laboral';
    protected $fillable = [
        'cod_relacion_laboral',
        'tipo'
    ];
    protected $hidden = [
        'created_at',
        'updated_at'
    ];
    public function obtenerRelacionLaboral()
    {
        return RelacionLaboral::all();
    }
    protected function obtenerRelacionLaboralId($id)
    {
        return RelacionLaboral::find($id);
    }
}
