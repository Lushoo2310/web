<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CapacitacionUsuario extends Model
{
    use HasFactory;
    protected $table ='capacitaciones_usuarios';
    protected $primaryKey ='id';
    protected $fillable=[
        'cod_capacitacion',
        'cod_user'
    ];
    protected $hidden=[
        'created_at',
        'updated_ad'
    ];
}
