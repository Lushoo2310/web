<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AsigAcademica extends Model
{
    use HasFactory;
    protected $table = 'asig_academicas';
    protected $primaryKey = 'cod_asig_academica';
    protected $fillable = [
        'carrera',
        'num_materias',
        'num_materias_m_s',
        'num_materias_m_n',
        'num_materias_d_s',
        'num_materias_d_n',
        'cod_p_academico',
    ];
    protected $hidden = [
        'created_at',
        'updated_at'
    ];

    public function periodoAcademico()
    {
        return $this->belongsTo(PeriodoAcademico::class, 'cod_p_academico', 'cod_p_academico');
    }
}
