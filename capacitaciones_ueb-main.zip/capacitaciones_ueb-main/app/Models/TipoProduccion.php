<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TipoProduccion extends Model
{
    use HasFactory;
    protected $table = 'tipo_producciones';
    protected $primaryKey = 'cod_tipo';
    protected $fillable = [
        'cod_tipo',
        'nombre'
    ];
    protected $hidden = [
        'created_at',
        'updated_at'
    ];

    public function obtenerTipoProducciones()
    {
        //return TipoProduccion::select('cod_tipo', 'nombre')->get();
        return TipoProduccion::all();
    }

    public function obtenerTipoProduccionPorId($id)
    {
        //return TipoProduccion::select('cod_tipo', 'nombre')->where('cod_tipo', $id)->first();
        return TipoProduccion::find($id);
    }

    // public function producciones()
    // {
    //     return $this->hasMany(Produccion::class, 'cod_tipo', 'cod_tipo');
    // }
}
