<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TipoPeriodo extends Model
{
    use HasFactory;
    protected $table='tipo_periodos';
    protected $primarykey ='cod_tipo_p';
    protected $fillable=[
        'cod_tipo_p',
        'nombre'
    ];
    protected $hidden =[
        'created_at',
        'updated_at'
    ];
    public function obtenerTipoPeriodos(){
        return TipoPeriodo::all();
    }
    public function obtenerTipoPeriodosId($id){
        return TipoPeriodo::find($id);
    }
}
