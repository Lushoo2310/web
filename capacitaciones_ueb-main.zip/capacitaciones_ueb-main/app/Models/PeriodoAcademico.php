<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PeriodoAcademico extends Model
{
    use HasFactory;
    protected $table = 'periodos_academicos';
    protected $primaryKey = 'cod_p_academico';
    protected $fillable = [
        'cod_p_academico',
        'fecha_inicio',
        'fecha_fin',
        'cod_user',
        'cod_tipo_p',

    ];
    protected $hidden = [
        'created_at',
        'updated_at'
    ];
    public function usuarios()
    {
        // return $this->belongsToMany(User::class, 'periodos_academicos:user');
        return $this->belongsToMany(User::class, 'code_user', 'cod_user');
    }

    public  function TipoPeriodo()
    {
        return $this->belongsTo(TipoPeriodo::class, 'cod_tipo_p', 'cod_tipo_p');
    }

    public function obtenerPeriodo()
    {
        return PeriodoAcademico::all();
    }

    public function obtenerPeriodoId($id)
    {
        return PeriodoAcademico::find($id);
    }
}
