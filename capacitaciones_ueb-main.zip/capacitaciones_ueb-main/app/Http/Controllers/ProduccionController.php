<?php

namespace App\Http\Controllers;

use App\Models\Produccion;
use Illuminate\Http\Request;
use App\Models\TipoProduccion;
use App\Models\RepositorioArt;
use Umpirsky\CountryList\CountryList;

class ProduccionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (auth()->check()) {
            $user = auth()->user();
            $tipoProduccion = TipoProduccion::all();
            $repositorioArt = RepositorioArt::all();
            $produccion = Produccion::where('cod_user', $user->cod_user)->get();
            return view('produccion.index', compact('tipoProduccion', 'repositorioArt', 'produccion'));
        } else {
            return redirect()->route('login');
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (auth()->check()) {
            $tipoProduccion = TipoProduccion::all();
            $repositorioArt = RepositorioArt::all();
            return view('produccion.create', compact('tipoProduccion', 'repositorioArt'));
        } else {
            return redirect()->route('login');
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if (auth()->check()) {
            $cod_user = $request->user()->cod_user;
            $codTipo = $request->input('cod_tipo');
            if ($codTipo == 1) {
                $data = $request->validate(
                    [
                        'titulo' => 'required|string',
                        'pais_revista' => 'string',
                        'nombre' => 'string',
                        'fecha_publicacion_art' => 'date',
                        'indexacion' => 'string',
                        'issn' => 'string',
                        'doi' => 'string',
                        'enlace_art' => 'string',
                        'cod_tipo' => 'required',
                        'cod_repositorio_art' => 'required',
                    ]
                );
            } else if ($codTipo == 2) {
                $data = $request->validate(
                    [
                        'titulo' => 'required|string',
                        'nombre' => 'string',
                        'editorial' => 'string',
                        'fecha_publicacion_lib' => 'date',
                        'isbn' => 'string',
                        'enlace_lib' => 'string',
                        'cod_tipo' => 'required',
                    ]
                );
            } else if ($codTipo == 3) {
                $data = $request->validate(
                    [
                        'titulo' => 'required|string',
                        'nombre' => 'string',
                        'fecha_evento' => 'date',
                        'pais_evento' => 'string',
                        'modalidad' => 'string',
                        'cod_tipo' => 'required',
                    ]
                );
            }
            $data['cod_user'] = $cod_user;
            Produccion::create($data);
            return redirect()->route('dashboard');
        } else {
            return redirect()->route('login');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Produccion  $produccion
     * @return \Illuminate\Http\Response
     */
    public function show(Produccion $produccion)
    {
        if ($produccion->cod_user == auth()->user()->cod_user) {
            return view('produccion.show', compact('produccion'));
        } else {
            return redirect()->route('produccion.index');
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Produccion  $produccion
     * @return \Illuminate\Http\Response
     */
    public function edit(Produccion $produccion)
    {
        if ($produccion->cod_user == auth()->user()->cod_user) {
            $tipoProduccion = TipoProduccion::all();
            $repositorioArt = RepositorioArt::all();
            return view('produccion.edit', compact('produccion', 'tipoProduccion', 'repositorioArt'));
        } else {
            return redirect()->route('produccion.index');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Produccion  $produccion
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Produccion $produccion)
    {
        if (auth()->check()) {
            $cod_user = $request->user()->cod_user;
            $codTipo = $request->input('cod_tipo');
            if ($codTipo == 1) {
                $data = $request->validate(
                    [
                        'titulo' => 'required|string',
                        'nombre' => 'required|string',
                        'pais_revista' => 'string',
                        'fecha_publicacion_art' => 'required|date',
                        'indexacion' => 'string',
                        'issn' => 'string',
                        'doi' => 'string',
                        'enlace_art' => 'string',
                        'cod_tipo' => 'required',
                        'cod_repositorio_art' => 'required',
                    ]
                );
            } else if ($codTipo == 2) {
                $data = $request->validate(
                    [
                        'titulo' => 'required|string',
                        'nombre' => 'required|string',
                        'editorial' => 'string',
                        'fecha_publicacion_lib' => 'required|date',
                        'isbn' => 'string',
                        'enlace_lib' => 'string',
                        'cod_tipo' => 'required',
                    ]
                );
            } else if ($codTipo == 3) {
                $data = $request->validate(
                    [
                        'titulo' => 'required|string',
                        'nombre' => 'required|string',
                        'fecha_evento' => 'date',
                        'pais_evento' => 'string',
                        'modalidad' => 'string',
                        'cod_tipo' => 'required',
                    ]
                );
            }
            $data['cod_user'] = $cod_user;
            $produccion->update($data);
            return redirect()->route('dashboard');
        } else {
            return redirect()->route('login');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Produccion  $produccion
     * @return \Illuminate\Http\Response
     */
    public function destroy(Produccion $produccion)
    {
        if ($produccion->cod_user == auth()->user()->cod_user) {
            $produccion->delete();
            return redirect()->route('dashboard');
        } else {
            return redirect()->route('produccion.index');
        }
    }
}
