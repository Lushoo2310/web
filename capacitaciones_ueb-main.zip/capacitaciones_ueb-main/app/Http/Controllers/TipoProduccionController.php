<?php

namespace App\Http\Controllers;

use App\Models\TipoProduccion;
use Illuminate\Http\Request;

class TipoProduccionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\TipoProduccion  $tipoProduccion
     * @return \Illuminate\Http\Response
     */
    public function show(TipoProduccion $tipoProduccion)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\TipoProduccion  $tipoProduccion
     * @return \Illuminate\Http\Response
     */
    public function edit(TipoProduccion $tipoProduccion)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\TipoProduccion  $tipoProduccion
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, TipoProduccion $tipoProduccion)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\TipoProduccion  $tipoProduccion
     * @return \Illuminate\Http\Response
     */
    public function destroy(TipoProduccion $tipoProduccion)
    {
        //
    }
}
