<?php

namespace App\Http\Controllers;

use App\Models\PeriodoAcademico;
use Illuminate\Http\Request;
use App\Models\TipoPeriodo;

class PeriodoAcademicoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // Verificar si el usuario está autenticado
        if (auth()->check()) {
            // Obtener el usuario autenticado
            $user = auth()->user();

            // Obtener los datos relacionados con el usuario autenticado
            $tipoPeriodo = TipoPeriodo::all();
            $periodoAcademico = PeriodoAcademico::where('cod_user', $user->cod_user)->get();

            return view('periodos.index', compact('tipoPeriodo', 'periodoAcademico'));
        } else {
            // Si el usuario no está autenticado, redirigirlo a la página de inicio de sesión
            return redirect()->route('login');
        }
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (auth()->check()) {
            $tipoPeriodo = TipoPeriodo::all();
            return view('periodos.create', compact('tipoPeriodo'));
        } else {
            return redirect()->route('login');
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if (auth()->check()) {
            $cod_user = $request->user()->cod_user;
            $data = $request->validate([
                'fecha_inicio' => 'required|date',
                'fecha_fin' => 'required|date',
                'cod_tipo_p' => 'required',

            ]);
            $data['cod_user'] = $cod_user;
            PeriodoAcademico::create($data);
            return redirect()->route('dashboard');
        } else {
            return redirect()->route('login');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\PeriodoAcademico  $periodoAcademico
     * @return \Illuminate\Http\Response
     */
    public function show(PeriodoAcademico $periodo)
    {
        if ($periodo->cod_user == auth()->user()->cod_user) {
            return view('periodos.show', compact('periodo'));
        } else {
            return redirect()->route('periodos.index');
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\PeriodoAcademico  $periodoAcademico
     * @return \Illuminate\Http\Response
     */
    public function edit(PeriodoAcademico $periodo)
    {
        if ($periodo->cod_user == auth()->user()->cod_user) {
            $tipoPeriodo = TipoPeriodo::all();
            return view('periodos.edit', compact('periodo', 'tipoPeriodo'));
        } else {
            return redirect()->route('periodos.index');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\PeriodoAcademico  $periodoAcademico
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, PeriodoAcademico $periodo)
    {
        if (auth()->check()) {
            $cod_user = $request->user()->cod_user;
            $data = $request->validate([
                'fecha_inicio' => 'required|date',
                'fecha_fin' => 'required|date',
                'cod_tipo_p' => 'required',

            ]);
            $data['cod_user'] = $cod_user;
            $periodo->update($data);
            return redirect()->route('periodos.index');
        } else {
            return redirect()->route('login');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\PeriodoAcademico  $periodoAcademico
     * @return \Illuminate\Http\Response
     */
    public function destroy(PeriodoAcademico $periodo)
    {
        if ($periodo->cod_user == auth()->user()->cod_user) {
            $periodo->delete();
            return redirect()->route('periodos.index');
        } else {
            return redirect()->route('login');
        }
    }
}
