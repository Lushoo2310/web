<?php

namespace App\Http\Controllers;

use App\Models\TipoFormacion;
use Illuminate\Http\Request;

class TipoFormacionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\TipoFormacion  $tipoFormacion
     * @return \Illuminate\Http\Response
     */
    public function show(TipoFormacion $tipoFormacion)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\TipoFormacion  $tipoFormacion
     * @return \Illuminate\Http\Response
     */
    public function edit(TipoFormacion $tipoFormacion)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\TipoFormacion  $tipoFormacion
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, TipoFormacion $tipoFormacion)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\TipoFormacion  $tipoFormacion
     * @return \Illuminate\Http\Response
     */
    public function destroy(TipoFormacion $tipoFormacion)
    {
        //
    }
}
