<?php

namespace App\Http\Controllers;

use App\Models\Formacion;
use Illuminate\Http\Request;
use App\Models\TipoFormacion;
use App\Models\User;

class FormacionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (auth()->check()) {
            $user = auth()->user();
            $tipoFormacion = TipoFormacion::all();
            $formacion = Formacion::where('cod_user', $user->cod_user)->get();
            return view('formacion.index', compact('tipoFormacion', 'formacion'));
        } else {
            return redirect()->route('login');
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (auth()->check()) {
            $tipoFormacion = TipoFormacion::all();
            return view('formacion.create', compact('tipoFormacion'));
        } else {
            return redirect()->route('login');
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if (auth()->check()) {
            $cod_user = $request->user()->cod_user;
            $data = $request->validate([
                'registro' => 'required',
                'titulo' => 'required',
                'cod_tipo' => 'required',
            ]);
            $data['cod_user'] = $cod_user;
            Formacion::create($data);
            return redirect()->route('dashboard');
        } else {
            return redirect()->route('login');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Formacion  $formacion
     * @return \Illuminate\Http\Response
     */
    public function show(Formacion $formacion)
    {
        if ($formacion->cod_user == auth()->user()->cod_user) {
            return view('formacion.show', compact('formacion'));
        } else {
            return redirect()->route('formacion.index');
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Formacion  $formacion
     * @return \Illuminate\Http\Response
     */
    public function edit(Formacion $formacion)
    {
        if ($formacion->cod_user == auth()->user()->cod_user) {
            $tipoFormacion = TipoFormacion::all();
            return view('formacion.edit', compact('formacion', 'tipoFormacion'));
        } else {
            return redirect()->route('formacion.index');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Formacion  $formacion
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Formacion $formacion)
    {
        if (auth()->check()) {
            $data = $request->validate([
                'registro' => 'required',
                'cod_tipo' => 'required',
            ]);
            $formacion->update($data);
            return redirect()->route('dashboard');
        } else {
            return redirect()->route('login');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Formacion  $formacion
     * @return \Illuminate\Http\Response
     */
    public function destroy(Formacion $formacion)
    {
        if ($formacion->cod_user == auth()->user()->cod_user) {
            $formacion->delete();
            return redirect()->route('formacion.index');
        } else {
            return redirect()->route('formacion.index');
        }
    }
}
