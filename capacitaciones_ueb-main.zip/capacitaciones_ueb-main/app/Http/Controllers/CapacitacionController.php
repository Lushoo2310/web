<?php

namespace App\Http\Controllers;

use App\Models\Capacitacion;
use Illuminate\Http\Request;
use Barryvdh\DomPDF\Facade\Pdf;

class CapacitacionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // Verificar si el usuario está autenticado
        if (auth()->check()) {
            // Obtener todas las capacitaciones del usuario autenticado
            $capacitaciones = Capacitacion::where('cod_user', auth()->user()->cod_user)->get();

            // Pasar las capacitaciones a la vista
            return view('capacitaciones.index', compact('capacitaciones'));
        }

        // Si el usuario no está autenticado, redirigirlo a la página de inicio de sesión
        return redirect()->route('login');
    }

    /*
    *Metodo para imprimir pdf
    */

    public function pdf()
    {
        $capacitaciones = Capacitacion::all();

        // Generar PDF desde la vista 'capacitaciones.pdf'
        $pdf = PDF::loadView('capacitaciones.pdf', compact('capacitaciones'));

        // Configuración de la orientación horizontal
        $pdf->setPaper('a4', 'landscape');

        return $pdf->stream();
    }



    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('capacitaciones.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $cod_user = $request->user()->cod_user;
        $data = $request->validate(
            [
                'evento' => 'required',
                'tipo_evento' => 'required',
                'fecha_evento' => 'required',
                'institucion_organizadora' => 'required',
                'pais' => 'required',
                'modalidad' => 'required',
                'num_horas' => 'required',
            ]
        );
        $data['cod_user'] = $request->user()->cod_user;
        capacitacion::create($data);
        return redirect()->route('dashboard');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Capacitacion  $capacitacion
     * @return \Illuminate\Http\Response
     */
    public function show(Capacitacion $capacitacion)
    {
        if ($capacitacion->cod_user == auth()->user()->cod_user) {
            return view('capacitaciones.show', compact('capacitacion'));
        }
        return redirect()->route('capacitaciones.index');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Capacitacion  $capacitacion
     * @return \Illuminate\Http\Response
     */
    public function edit(Capacitacion $capacitacion)
    {
        if ($capacitacion->cod_user == auth()->user()->cod_user) {
            return view('capacitaciones.edit', compact('capacitacion'));
        }
        return redirect()->route('capacitaciones.index');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Capacitacion  $capacitacion
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Capacitacion $capacitacion)
    {
        $data = $request->validate(
            [
                'evento' => 'required',
                'tipo_evento' => 'required',
                'fecha_evento' => 'required',
                'institucion_organizadora' => 'required',
                'pais' => 'required',
                'modalidad' => 'required',
                'num_horas' => 'required',
            ]
        );
        $data['cod_user'] = $request->user()->cod_user;
        capacitacion::create($data);
        return redirect()->route('dashboard');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Capacitacion  $capacitacion
     * @return \Illuminate\Http\Response
     */
    public function destroy(Capacitacion $capacitacion)
    {
        if ($capacitacion->cod_user == auth()->user()->cod_user) {
            $capacitacion->delete();
            return redirect()->route('capacitaciones.index');
        }

        // Agregar una redirección o manejo de error en caso de que la capacitación no pertenezca al usuario
        return redirect()->route('capacitaciones.index')->with('error', 'No tienes permiso para eliminar esta capacitación');
    }
}
