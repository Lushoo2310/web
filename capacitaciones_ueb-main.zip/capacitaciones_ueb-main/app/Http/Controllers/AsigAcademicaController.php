<?php

namespace App\Http\Controllers;

use App\Models\AsigAcademica;
use Illuminate\Http\Request;
use App\Models\PeriodoAcademico;

class AsigAcademicaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // $asigacademica = AsigAcademica::all();
        // return view('asigacademica.index', compact('asigacademica'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $periodoacademico = PeriodoAcademico::all(); // Renombra para ser más descriptivo
        return view('asigacademica.create', compact('periodoacademico')); // Pasar la variable a la vista
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->validate([
            'carrera' => 'required|string',
            'num_materias' => 'required|numeric',
            'num_materias_m_s' => 'required|numeric',
            'num_materias_m_n' => 'required|numeric',
            'num_materias_d_s' => 'required|numeric',
            'num_materias_d_n' => 'required|numeric',
            'cod_p_academico' => 'required|numeric|exists:periodos_academicos,cod_p_academico',
        ], [
            'cod_p_academico.exists' => 'El periodo académico seleccionado no existe en la base de datos.',
        ]);

        AsigAcademica::create($data);
        return redirect()->route('periodos.index')->with('status', 'Asignación Académica creada exitosamente');
    }



    /**
     * Display the specified resource.
     *
     * @param  \App\Models\AsigAcademica  $asigAcademica
     * @return \Illuminate\Http\Response
     */
    public function show(AsigAcademica $asigAcademica)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\AsigAcademica  $asigAcademica
     * @return \Illuminate\Http\Response
     */
    public function edit(AsigAcademica $asigAcademica)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\AsigAcademica  $asigAcademica
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, AsigAcademica $asigAcademica)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\AsigAcademica  $asigAcademica
     * @return \Illuminate\Http\Response
     */
    public function destroy(AsigAcademica $asigAcademica)
    {
        //
    }
}
