<x-app-layout>
  {{-- <x-slot name="header">
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
      {{ __('Bienvenido') }}
    </h2>
  </x-slot> --}}

  <div class="py-6">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
      <div class="bg-white overflow-hidden shadow-sm rounded-lg">
        <div class="p-6 text-gray-900">

          <!-- Título -->
          <h3 class="text-lg font-medium leading-6 text-gray-900 mb-4">
            Periodo Registrado
          </h3>

          <!-- Detalles del periodo -->
          <div class="bg-gray-50 shadow rounded-md mb-4 p-4">
            <dl
              class="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6 text-sm sm:text-base">
              <div class="sm:col-span-1">
                <dt class="font-medium text-gray-500">
                  Inicio de Período Académico
                </dt>
                <dd class="mt-1 text-gray-900">
                  {{ $periodo->fecha_inicio }}
                </dd>
              </div>
              <div class="sm:col-span-1">
                <dt class="font-medium text-gray-500">
                  Fin de Período Académico
                </dt>
                <dd class="mt-1 text-gray-900">
                  {{ $periodo->fecha_fin }}
                </dd>
              </div>
              <div class="sm:col-span-1">
                <dt class="font-medium text-gray-500">
                  Tipo de Período Académico
                </dt>
                <dd class="mt-1 text-gray-900">
                  {{ $periodo->tipoPeriodo->nombre }}
                </dd>
              </div>
            </dl>
          </div>

          <!-- Botones de acción -->
          <div class="flex justify-end">
            <div class="mr-4">
              <x-secondary-button>
                <a
                  href="{{ route('periodos.edit', $periodo->cod_p_academico) }}">
                  Editar Periodo
                </a>
              </x-secondary-button>
            </div>
            <form
              action="{{ route('periodos.destroy', $periodo->cod_p_academico) }}"
              method="POST">
              @csrf
              @method('DELETE')
              <x-danger-button type="submit">
                Eliminar Periodo
              </x-danger-button>
            </form>
          </div>

        </div>
      </div>
    </div>
  </div>
</x-app-layout>
