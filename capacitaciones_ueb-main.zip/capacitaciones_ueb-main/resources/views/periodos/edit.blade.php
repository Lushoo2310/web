<x-app-layout>
  <x-slot name="header">
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
      {{ __('Registro de Periodos Academios') }}
    </h2>
  </x-slot>
  <div class="py-12">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
      <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
        <div class="p-6 text-gray-900">
          <!-- component -->
          <!-- Regitro Periodo -->

          <div class="grid gap-40 gap-y-2 text-sm grid-cols-1 lg:grid-cols-2">
            <form method="POST"
              action="{{ route('periodos.update', $periodo->cod_p_academico) }}">
              @csrf
              @method('PUT')
              <h2 class="text-lg font-medium text-gray-900">
                {{ __('Periodo Academico') }}
              </h2>

              <div class="lg:col-span-2">

                <div
                  class="grid gap-4 gap-y-2 text-sm grid-cols-1 md:grid-cols-5">
                  <div class="md:col-span-5">
                    <x-input-label for="fecha_inicio" :value="__('Inicio de Perio Academico')" />
                    <x-text-input id="fecha_inicio" name="fecha_inicio"
                      type="date" class="mt-1 block w-full"
                      value="{{ old('fecha_inicio') ?? $periodo->fecha_inicio }}"
                      autofocus autocomplete="fecha_inicio" />
                    <x-input-error class="mt-2" :messages="$errors->get('fecha_inicio')" />
                  </div>

                  <div class="md:col-span-5">
                    <x-input-label for="fecha_fin" :value="__('Fin de Perio Academico')" />
                    <x-text-input id="fecha_fin" name="fecha_fin" type="date"
                      class="mt-1 block w-full"
                      value="{{ old('fecha_fin') ?? $periodo->fecha_fin }}"
                      autofocus autocomplete="fecha_fin" />
                    <x-input-error class="mt-2" :messages="$errors->get('fecha_fin')" />
                  </div>
                  {{-- <div class="md:col-span-5">
                    <x-input-label for="name" :value="__('Estado')" />
                    <x-text-input id="name" name="name" type="text"
                      class="mt-1 block w-full" :value="old('name')" required
                      autofocus autocomplete="name" />
                    <x-input-error class="mt-2" :messages="$errors->get('name')" />
                  </div> --}}

                  {{-- <p>{{ $periodoacademico->user->cod_user }}</p> --}}
                </div>

              </div>
              <!--Tipo Capacitacion-->
              <h2 class="text-lg font-medium text-gray-900 mt-4">
                {{ __('Tipo de Periodo Academico') }}
              </h2>
              <div
                class="grid gap-4 gap-y-2 text-sm grid-cols-1 lg:grid-cols-3">
                @foreach ($tipoPeriodo as $tp)
                  <div class="md:col-span-5">
                    <label class="flex radio p-2 cursor-pointer">
                      <input
                        {{ $periodo->tipoPeriodo->cod_tipo_p == $tp->cod_tipo_p ? 'checked' : '' }}
                        class="my-auto transform scale-125" type="radio"
                        name="cod_tipo_p"
                        value="{{ old('cod_tipo_p') ?? $tp->cod_tipo_p }}" />
                      <div class="title px-2">
                        {{ old('nombre') ?? $tp->nombre }}
                      </div>
                    </label>
                  </div>
                @endforeach


                <div class="md:col-span-5 text-right">
                  <x-primary-button class="ml-4">
                    <input class="btn btn-secondary mb-2" value="Registrar"
                      type="submit">
                  </x-primary-button>
                </div>

              </div>
              <!---->
            </form>


            <!-- Asignacion Acdemica -->
            <section class="space-y-6">
              <header>
                <h2 class="text-lg font-medium text-gray-900">
                  {{ __('Agregar Asignacion Academica !') }}
                </h2>
              </header>

              <x-danger-button x-data=""
                x-on:click.prevent="$dispatch('open-modal', 'confirm-user-deletion')">
                {{ __('Agregar') }}</x-danger-button>

              <x-modal name="confirm-user-deletion" :show="$errors->userDeletion->isNotEmpty()" focusable>
                <form method="POST" action="" class="p-6">
                  @csrf
                  <div class="md:col-span-5">
                    <x-input-label for="name" :value="__('Carrera')" />
                    <x-text-input id="name" name="name" type="text"
                      class="mt-1 block w-full" :value="old('name')" required
                      autofocus autocomplete="name" />
                    <x-input-error class="mt-2" :messages="$errors->get('name')" />
                  </div>

                  <div class="md:col-span-3">
                    <x-input-label for="name" :value="__('Numero de Materias')" />
                    <x-text-input id="name" name="name" type="text"
                      class="mt-1 block w-full" :value="old('name')" required
                      autofocus autocomplete="name" />
                    <x-input-error class="mt-2" :messages="$errors->get('name')" />
                  </div>

                  <div class="md:col-span-2">
                    <x-input-label for="name" :value="__('num_materias_s')" />
                    <x-text-input id="name" name="name" type="text"
                      class="mt-1 block w-full" :value="old('name')" required
                      autofocus autocomplete="name" />
                    <x-input-error class="mt-2" :messages="$errors->get('name')" />
                  </div>

                  <div class="md:col-span-2">
                    <x-input-label for="name" :value="__('num_materias_n')" />
                    <x-text-input id="name" name="name" type="text"
                      class="mt-1 block w-full" :value="old('name')" required
                      autofocus autocomplete="name" />
                    <x-input-error class="mt-2" :messages="$errors->get('name')" />
                  </div>

                  <div class="md:col-span-2">
                    <x-input-label for="name" :value="__('num_materias_d_s')" />
                    <x-text-input id="name" name="name" type="text"
                      class="mt-1 block w-full" :value="old('name')" required
                      autofocus autocomplete="name" />
                    <x-input-error class="mt-2" :messages="$errors->get('name')" />
                  </div>

                  <div class="md:col-span-1">
                    <x-input-label for="name" :value="__('num_materias_d_n')" />
                    <x-text-input id="name" name="name" type="text"
                      class="mt-1 block w-full" :value="old('name')" required
                      autofocus autocomplete="name" />
                    <x-input-error class="mt-2" :messages="$errors->get('name')" />
                  </div>
                  <div class="md:col-span-5 text-right mt-4">
                    <x-primary-button class="ml-4">
                      <a href=""
                        class="btn btn-secondary mb-2">Registrar</a>
                    </x-primary-button>
                  </div>
                </form>
              </x-modal>
            </section>

          </div>
        </div>
      </div>
    </div>
  </div>
</x-app-layout>
