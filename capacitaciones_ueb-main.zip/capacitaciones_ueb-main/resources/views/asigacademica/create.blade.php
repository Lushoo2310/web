<x-app-layout>
  <x-slot name="header">
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
      {{ __('Registro de Asignación Académica') }}
    </h2>
  </x-slot>

  <div class="py-12">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
      <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
        <div class="p-6 text-gray-900">

          <form method="POST" action="{{ route('asigacademica.store') }}">
            @csrf

            <div class="lg:col-span-2">
              <div class="grid gap-4 gap-y-2 text-sm grid-cols-1 md:grid-cols-3">
                <!-- Carrera -->
                <div class="mt-2">
                  <x-input-label for="carrera" :value="__('Carrera')" />
                  <x-text-input id="carrera" class="block mt-1 w-full"
                    type="text" name="carrera" :value="old('carrera')"
                    autocomplete="carrera" autofocus />
                  <x-input-error :messages="$errors->get('carrera')" class="mt-2" />
                </div>
                <!-- num_materias -->
                <div class="mt-2">
                  <x-input-label for="num_materias" :value="__('Número de Materias')" />
                  <x-text-input id="num_materias" class="block mt-1 w-full"
                    type="text" name="num_materias" :value="old('num_materias')"
                    autocomplete="num_materias" autofocus />
                  <x-input-error :messages="$errors->get('num_materias')" class="mt-2" />
                </div>
                <!-- num_materias_m_s -->
                <div class="mt-2">
                  <x-input-label for="num_materias_m_s" :value="__('num_materias_m_s')" />
                  <x-text-input id="num_materias_m_s" class="block mt-1 w-full"
                    type="text" name="num_materias_m_s" :value="old('num_materias_m_s')"
                    autocomplete="num_materias_m_s" autofocus />
                  <x-input-error :messages="$errors->get('num_materias_m_s')" class="mt-2" />
                </div>
                <!-- num_materias_m_n -->
                <div class="mt-2">
                  <x-input-label for="num_materias_m_n" :value="__('num_materias_m_n')" />
                  <x-text-input id="num_materias_m_n" class="block mt-1 w-full"
                    type="text" name="num_materias_m_n" :value="old('num_materias_m_n')"
                    autocomplete="num_materias_m_n" autofocus />
                  <x-input-error :messages="$errors->get('num_materias_m_n')" class="mt-2" />
                </div>
                <!-- num_materias_d_s -->
                <div class="mt-2">
                  <x-input-label for="num_materias_d_s" :value="__('num_materias_d_s')" />
                  <x-text-input id="num_materias_d_s" class="block mt-1 w-full"
                    type="text" name="num_materias_d_s" :value="old('num_materias_d_s')"
                    autocomplete="num_materias_d_s" />
                  <x-input-error :messages="$errors->get('num_materias_d_s')" class="mt-2" />
                </div>

                <!-- num_materias_d_n -->
                <div class="mt-2">
                  <x-input-label for="num_materias_d_n" :value="__('num_materias_d_n')" />

                  <x-text-input id="num_materias_d_n" class="block mt-1 w-full"
                    type="text" name="num_materias_d_n" :value="old('num_materias_d_n')"
                    autocomplete="num_materias_d_n" />

                  <x-input-error :messages="$errors->get('num_materias_d_n')" class="mt-2" />
                </div>

              </div>
            </div>
            <div class="flex items-center justify-end mt-4">
              <x-primary-button class="ml-4">
                {{ __('Registrar') }}
              </x-primary-button>
            </div>

          </form>

        </div>
      </div>
    </div>
  </div>
</x-app-layout>
