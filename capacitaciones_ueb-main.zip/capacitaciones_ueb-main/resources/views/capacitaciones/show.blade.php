<x-app-layout>
  {{-- <x-slot name="header">
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
      {{ __('Bienvenido') }}
    </h2>
  </x-slot> --}}

  <div class="py-6">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
      <div class="bg-white overflow-hidden shadow-sm rounded-lg">
        <div class="p-6 text-gray-900">

          <!-- Título -->
          <h3 class="text-lg font-medium leading-6 text-gray-900 mb-4">
            Capacitacion Registrada
          </h3>

          <!-- Detalles del periodo -->
          <div class="bg-gray-50 shadow rounded-md mb-4 p-4">
            <dl
              class="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6 text-sm sm:text-base">
              <div class="sm:col-span-1">
                <dt class="font-medium text-gray-500">
                  Evento
                </dt>
                <dd class="mt-1 text-gray-900">
                  {{ $capacitacion->evento }}
                </dd>
              </div>
              <div class="sm:col-span-1">
                <dt class="font-medium text-gray-500">
                  Tipo de Evento
                </dt>
                <dd class="mt-1 text-gray-900">
                  {{ $capacitacion->tipo_evento }}
                </dd>
              </div>
              <div class="sm:col-span-1">
                <dt class="font-medium text-gray-500">
                  Fecha del Evento
                </dt>
                <dd class="mt-1 text-gray-900">
                  {{ $capacitacion->fecha_evento }}
                </dd>
              </div>
              <div class="sm:col-span-1">
                <dt class="font-medium text-gray-500">
                  Institucion
                  Organizadora
                </dt>
                <dd class="mt-1 text-gray-900">
                  {{ $capacitacion->institucion_organizadora }}
                </dd>
              </div>
              <div class="sm:col-span-1">
                <dt class="font-medium text-gray-500">
                  Pais
                </dt>
                <dd class="mt-1 text-gray-900">
                  {{ $capacitacion->pais }}
                </dd>
              </div>
              <div class="sm:col-span-1">
                <dt class="font-medium text-gray-500">
                  Modalidad
                </dt>
                <dd class="mt-1 text-gray-900">
                  {{ $capacitacion->modalidad }}
                </dd>
              </div>
              <div class="sm:col-span-1">
                <dt class="font-medium text-gray-500">
                  Numero de
                  Horas
                </dt>
                <dd class="mt-1 text-gray-900">
                  {{ $capacitacion->num_horas }}
                </dd>
              </div>
            </dl>
          </div>

          <!-- Botones de acción -->
          <div class="flex justify-end">
            <div class="mr-4">
              <x-secondary-button>
                <a
                  href="{{ route('capacitaciones.edit', $capacitacion->cod_capacitacion) }}">
                  Editar Capacitacion
                </a>
              </x-secondary-button>
            </div>
            <form
              action="{{ route('capacitaciones.destroy', $capacitacion->cod_capacitacion) }}"
              method="POST">
              @csrf
              @method('DELETE')
              <x-danger-button type="submit">
                Eliminar Capacitacion
              </x-danger-button>
            </form>
          </div>

        </div>
      </div>
    </div>
  </div>
</x-app-layout>
