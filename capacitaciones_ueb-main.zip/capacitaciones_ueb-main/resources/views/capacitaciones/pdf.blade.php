<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Capacitación de Docentes</title>
  <link
    href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.16/dist/tailwind.min.css"
    rel="stylesheet">

  <!-- Estilo de impresión para formato horizontal -->
  <style>
    @media print {
      @page {
        size: landscape;
      }
    }
  </style>
</head>

<body class="bg-gray-100 p-8">

  <div class="max-w-4xl mx-auto bg-white p-6 rounded-lg shadow">
    <img src="assets/administrativas.png" alt=""
      class="absolute top-0 left-0 w-16 h-16 m-4">
    <h5 class="text-center font-bold mb-4">FACULTAD DE CIENCIAS ADMINISTRATIVAS,
      GESTIÓN EMPRESARIAL E INFORMÁTICA</h5>
    <h5 class="text-center font-bold mb-4">CAPACITACIÓNES DEL DOCENTES</h5>

    <div class="p-6 text-gray-900">
      <table class="min-w-max w-full table-auto">
        <thead>
          <tr class="bg-gray-200 text-gray-600 uppercase text-xs font-semibold">
            <th class="py-3 px-6 text-center">Docente</th>
            <th class="py-3 px-6 text-center">Evento</th>
            <th class="py-3 px-6 text-center">Tipo de Evento</th>
            <th class="py-3 px-6 text-center">Fecha del Evento</th>
            <th class="py-3 px-6 text-center">Institucion Organizadora</th>
            <th class="py-3 px-6 text-center">Pais</th>
            <th class="py-3 px-6 text-center">Modalidad</th>
            <th class="py-3 px-6 text-center">Numero de Horas</th>
          </tr>
        </thead>


        <tbody class="text-gray-600 text-sm font-light">
          @foreach ($capacitaciones as $capacitacion)
            <tr class="border-b border-gray-200 hover:bg-gray-100">
              <td class="py-3 px-6 text-left ">
                <div class="flex items-center">
                  <span
                    class="font-medium">{{ Auth::user()->nombres . ' ' . Auth::user()->apellidos }}</span>
                </div>
              </td>
              <td class="py-3 px-6 text-left ">
                <div class="flex items-center">
                  <span class="font-medium">{{ $capacitacion->evento }}</span>
                </div>
              </td>
              <td class="py-3 px-6 text-left ">
                <div class="flex items-center">
                  <span
                    class="font-medium">{{ $capacitacion->tipo_evento }}</span>
                </div>
              </td>
              <td class="py-3 px-6 text-left">
                <div class="flex items-center">
                  <span>{{ $capacitacion->fecha_evento }}</span>
                </div>
              </td>
              <td class="py-3 px-6 text-left">
                <div class="flex items-center">
                  <span>{{ $capacitacion->institucion_organizadora }}</span>
                </div>
              </td>
              <td class="py-3 px-6 text-left">
                <div class="flex items-center">
                  <span>{{ $capacitacion->pais }}</span>
                </div>
              </td>
              <td class="py-3 px-6 text-left">
                <div class="flex items-center">
                  <div class="mr-2">
                  </div>
                  <span
                    class="font-medium">{{ $capacitacion->modalidad }}</span>
                </div>
              </td>
              <td class="py-3 px-6 text-center">
                <span
                  class="bg-purple-200 text-purple-600 py-1 px-3 rounded-full text-xs">{{ $capacitacion->num_horas }}</span>
              </td>
            </tr>
          @endforeach
        </tbody>
      </table>
    </div>
  </div>

</body>

</html>
