<x-app-layout>
  <div class="py-6">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
      <div class="bg-white overflow-hidden shadow-sm rounded-lg">
        <div class="p-6 text-gray-900">

          <!-- Título -->
          <h3 class="text-lg font-medium leading-6 text-gray-900 mb-4">
            Producciones Registradas
          </h3>

          <!-- Detalles del periodo -->
          <div class="bg-gray-50 shadow rounded-md mb-4 p-4">
            <dl
              class="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6 text-sm sm:text-base">

              <div class="sm:col-span-1">
                <dt class="font-medium text-gray-500">
                  Tipo de Producción Académico
                </dt>
                <dd class="mt-1 text-gray-900">
                  {{ $produccion->tipoProduccion->nombre }}
                </dd>
              </div>

              @if ($produccion->cod_tipo == 1)
                @if ($produccion->titulo != null)
                  <div class="sm:col-span-1">
                    <dt class="font-medium text-gray-500">
                      Titulo
                    </dt>
                    <dd class="mt-1 text-gray-900">
                      {{ $produccion->titulo }}
                    </dd>
                  </div>
                @endif

                <div class="sm:col-span-1">
                  <dt class="font-medium text-gray-500">
                    Nombre Revista
                  </dt>
                  <dd class="mt-1 text-gray-900">
                    {{ $produccion->nombre }}
                  </dd>
                </div>

                <div class="sm:col-span-1">
                  <dt class="font-medium text-gray-500">
                    Pais Revista
                  </dt>
                  <dd class="mt-1 text-gray-900">
                    {{ $produccion->pais_revista }}
                  </dd>
                </div>

                <div class="sm:col-span-1">
                  <dt class="font-medium text-gray-500">
                    Fecha de Publicacion
                  </dt>
                  <dd class="mt-1 text-gray-900">
                    {{ $produccion->fecha_publicacion_art }}
                  </dd>
                </div>

                <div class="sm:col-span-1">
                  <dt class="font-medium text-gray-500">
                    Indexacion
                  </dt>
                  <dd class="mt-1 text-gray-900">
                    {{ $produccion->indexacion }}
                  </dd>
                </div>

                <div class="sm:col-span-1">
                  <dt class="font-medium text-gray-500">
                    ISSN
                  </dt>
                  <dd class="mt-1 text-gray-900">
                    {{ $produccion->issn }}
                  </dd>
                </div>

                <div class="sm:col-span-1">
                  <dt class="font-medium text-gray-500">
                    DOI
                  </dt>
                  <dd class="mt-1 text-gray-900">
                    {{ $produccion->doi }}
                  </dd>
                </div>

                <div class="sm:col-span-1">
                  <dt class="font-medium text-gray-500">
                    Enlace
                  </dt>
                  <dd class="mt-1 text-sm text-gray-900 sm:col-span-2 sm:mt-0">
                    <a
                      href="{{ $produccion->enlace_art }}">{{ $produccion->enlace_art }}</a>
                  </dd>
                </div>
              @endif

              @if ($produccion->cod_tipo == 2)
                <!-- Campos específicos para Libro -->
                @if ($produccion->titulo != null)
                  <div class="sm:col-span-1">
                    <dt class="font-medium text-gray-500">
                      Titulo
                    </dt>
                    <dd class="mt-1 text-gray-900">
                      {{ $produccion->titulo }}
                    </dd>
                  </div>
                @endif

                <div class="sm:col-span-1">
                  <dt class="font-medium text-gray-500">
                    Nombre Libro
                  </dt>
                  <dd class="mt-1 text-gray-900">
                    {{ $produccion->nombre }}
                  </dd>
                </div>

                <div class="sm:col-span-1">
                  <dt class="font-medium text-gray-500">
                    Editorial
                  </dt>
                  <dd class="mt-1 text-gray-900">
                    {{ $produccion->editorial }}
                  </dd>
                </div>

                <div class="sm:col-span-1">
                  <dt class="font-medium text-gray-500">
                    Fecha de Publicacion
                  </dt>
                  <dd class="mt-1 text-gray-900">
                    {{ $produccion->fecha_publicacion_lib }}
                  </dd>
                </div>

                <div class="sm:col-span-1">
                  <dt class="font-medium text-gray-500">
                    ISBN
                  </dt>
                  <dd class="mt-1 text-gray-900">
                    {{ $produccion->isbn }}
                  </dd>
                </div>

                <div class="sm:col-span-1">
                  <dt class="font-medium text-gray-500">
                    Enlace
                  </dt>
                  <dd class="mt-1 text-sm text-gray-900 sm:col-span-2 sm:mt-0">
                    <a
                      href="{{ $produccion->enlace_lib }}">{{ $produccion->enlace_lib }}</a>
                  </dd>
                </div>
              @endif

              @if ($produccion->cod_tipo == 3)
                <!-- Campos específicos para Ponencia -->

                @if ($produccion->titulo != null)
                  <div class="sm:col-span-1">
                    <dt class="font-medium text-gray-500">
                      Titulo
                    </dt>
                    <dd class="mt-1 text-gray-900">
                      {{ $produccion->titulo }}
                    </dd>
                  </div>
                @endif

                <div class="sm:col-span-1">
                  <dt class="font-medium text-gray-500">
                    Nombre Seminario/Congreso
                  </dt>
                  <dd class="mt-1 text-gray-900">
                    {{ $produccion->nombre }}
                  </dd>
                </div>

                <div class="sm:col-span-1">
                  <dt class="font-medium text-gray-500">
                    Pais del Evento
                  </dt>
                  <dd class="mt-1 text-gray-900">
                    {{ $produccion->pais_evento }}
                  </dd>
                </div>

                <div class="sm:col-span-1">
                  <dt class="font-medium text-gray-500">
                    Fecha del Evento
                  </dt>
                  <dd class="mt-1 text-gray-900">
                    {{ $produccion->fecha_evento }}
                  </dd>
                </div>

                <div class="sm:col-span-1">
                  <dt class="font-medium text-gray-500">
                    Modalidad
                  </dt>
                  <dd class="mt-1 text-gray-900">
                    {{ $produccion->modalidad }}
                  </dd>
                </div>
              @endif

              <!-- Campos comunes a todos los tipos de producción -->

              {{-- <div class="sm:col-span-1">
                <dt class="font-medium text-gray-500">
                  SJR
                </dt>
                <dd class="mt-1 text-gray-900">
                  {{ $produccion->sjr }}
                </dd>
              </div> --}}

              {{-- <div class="sm:col-span-1">
                <dt class="font-medium text-gray-500">
                  JCR
                </dt>
                <dd class="mt-1 text-gray-900">
                  {{ $produccion->jcr }}
                </dd>
              </div> --}}

              {{-- <div class="sm:col-span-1">
                <dt class="font-medium text-gray-500">
                  Otros Repositorios
                </dt>
                <dd class="mt-1 text-gray-900">
                  {{ $produccion->otro_repositorio }}
                </dd>
              </div> --}}

              @if ($produccion->cod_tipo == 1)
                @if ($produccion && $produccion->repositorioArt)
                  <div class="sm:col-span-1">
                    <dt class="font-medium text-gray-500">
                      Nombre del repositorio
                    </dt>
                    <dd class="mt-1 text-gray-900">
                      {{ $produccion->repositorioArt->nombre ?? '' }}
                    </dd>
                  </div>
                @endif
              @endif
            </dl>
          </div>

          <!-- Botones de acción -->
          <div class="flex justify-end">
            <div class="mr-4">
              <x-secondary-button>
                <a
                  href="{{ route('produccion.edit', $produccion->cod_produccion) }}">
                  Editar Producción
                </a>
              </x-secondary-button>
            </div>
            <form
              action="{{ route('produccion.destroy', $produccion->cod_produccion) }}"
              method="POST">
              @csrf
              @method('DELETE')
              <x-danger-button type="submit">
                Eliminar Producción
              </x-danger-button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>
</x-app-layout>
