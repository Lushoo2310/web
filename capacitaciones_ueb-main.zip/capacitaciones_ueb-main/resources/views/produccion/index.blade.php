<x-app-layout>
  <x-slot name="header">
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
      {{ __('Producción Académica Registrada Correctamente') }}
    </h2>
  </x-slot>

  <div class="py-12">
    <div class="max-w-8xl mx-auto sm:px-6 lg:px-8">
      <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
        <div class="p-6 text-gray-900">
          <!-- Navbar -->
          <ul class="flex mb-6">
            <li class="mr-6">
              <a href="#" id="nav-articulo"
                class="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-gray-500 bg-white hover:text-gray-700 hover:bg-gray-100 focus:outline-none focus:border-gray-300 focus:shadow-outline-blue active:bg-gray-200 transition duration-150 ease-in-out">
                Artículo
              </a>
            </li>
            <li class="mr-6">
              <a href="#" id="nav-libro"
                class="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-gray-500 bg-white hover:text-gray-700 hover:bg-gray-100 focus:outline-none focus:border-gray-300 focus:shadow-outline-blue active:bg-gray-200 transition duration-150 ease-in-out">
                Libro/Capítulo
              </a>
            </li>
            <li>
              <a href="#" id="nav-ponencia"
                class="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-gray-500 bg-white hover:text-gray-700 hover:bg-gray-100 focus:outline-none focus:border-gray-300 focus:shadow-outline-blue active:bg-gray-200 transition duration-150 ease-in-out">Ponencia
                (Seminario/Congreso)</a>
            </li>
          </ul>

          <!-- Sección de Artículos -->
          <div id="seccion-articulo">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
              {{ __('Producción de Artículos Científicos') }}
            </h2>
            <table class="min-w-max w-full table-auto">
              <!-- Resto del código para la tabla de artículos -->
              <thead>
                <tr
                  class="bg-gray-200 text-gray-600 uppercase text-sm leading-normal">
                  <th class="py-3 px-6 text-left">Titulo</th>
                  <th class="py-3 px-6 text-left">Nombre Revista</th>
                  <th class="py-3 px-6 text-left">País Revista</th>
                  <th class="py-3 px-6 text-left">Fecha de Publicacion </th>
                  <th class="py-3 px-6 text-left">Indexación</th>
                  <th class="py-3 px-6 text-left">ISSN</th>
                  <th class="py-3 px-6 text-left">DOI</th>
                  <th class="py-3 px-6 text-left">Enlace</th>
                  <th class="py-3 px-6 text-left">Nombre del <br />repositorio
                  </th>
                  <th class="py-3 px-6 text-center">Aciones</th>
                </tr>
              </thead>

              <tbody class="text-gray-600 text-sm font-light">
                @if (count($produccion->where('cod_tipo', 1)) == 0)
                  <tr class="border-b border-gray-200 hover:bg-gray-100">
                    <td class="py-3 px-6 text-left" colspan="10">
                      <div class="col-md-4 mx-auto">
                        <div class="card card-body text-center">
                          <p>No existen capacitaciones registradas</p>
                          <a class="text-green-600"
                            href="{{ route('produccion.create') }}">
                            Registrar Artículos Científicos
                          </a>
                        </div>
                      </div>
                    </td>
                  </tr>
                @endif

                @foreach ($produccion as $pd)
                  @if ($pd->cod_tipo == 1)
                    <tr class="border-b border-gray-200 hover:bg-gray-100">
                      <td class="py-3 px-6 text-left ">
                        <div class="flex items-center">
                          <span class="font-medium">{{ $pd->titulo }}</span>
                        </div>
                      <td class="py-3 px-6 text-left">
                        <div class="flex items-center">
                          <span>{{ $pd->nombre }}</span>
                        </div>
                      </td>
                      <td class="py-3 px-6 text-left">
                        <div class="flex items-center">
                          <span>{{ $pd->pais_revista }}</span>
                        </div>
                      </td>
                      <td class="py-3 px-6 text-left">
                        <div class="flex items-center">
                          <span>{{ $pd->fecha_publicacion_art }}</span>
                        </div>
                      </td>
                      <td class="py-3 px-6 text-left">
                        <div class="flex items-center">
                          <span>{{ $pd->indexacion }}</span>
                        </div>
                      </td>
                      <td class="py-3 px-6 text-left">
                        <div class="flex items-center">
                          <span>{{ $pd->issn }}</span>
                        </div>
                      </td>
                      <td class="py-3 px-6 text-left">
                        <div class="flex items-center">
                          <span>{{ $pd->doi }}</span>
                        </div>
                      </td>
                      <td class="py-3 px-6 text-left">
                        <div class="flex items-center">
                          <span>{{ $pd->enlace_art }}</span>
                        </div>
                      </td>
                      <td class="py-3 px-6 text-left">
                        <div class="flex items-center">
                          <div class="mr-2">
                          </div>
                          <span
                            class="font-medium">{{ $pd->repositorioArt->nombre ?? '' }}</span>
                        </div>
                      </td>

                      <td class="py-3 px-6 text-center">
                        <div class="flex item-center justify-center">
                          <div
                            class="w-4 mr-2 transform hover:text-purple-500 hover:scale-110">
                            <a href="{{ route('produccion.show', $pd->cod_produccion) }}"
                              class="btn btn-secondary mb-2">
                              <svg xmlns="http://www.w3.org/2000/svg"
                                fill="none" viewBox="0 0 24 24"
                                stroke="currentColor">
                                <path stroke-linecap="round"
                                  stroke-linejoin="round" stroke-width="2"
                                  d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                <path stroke-linecap="round"
                                  stroke-linejoin="round" stroke-width="2"
                                  d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                              </svg>
                            </a>
                          </div>
                          @if (Auth::user()->cod_rol == 1)
                            <div
                              class="w-4 mr-2 transform hover:text-green-500 hover:scale-110">
                              <a href="{{ route('produccion.edit', $pd->cod_produccion) }}"
                                class="btn btn-secondary mb-2">
                                <svg xmlns="http://www.w3.org/2000/svg"
                                  fill="none" viewBox="0 0 24 24"
                                  stroke="currentColor">
                                  <path stroke-linecap="round"
                                    stroke-linejoin="round" stroke-width="2"
                                    d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                                </svg>
                              </a>
                            </div>
                            <form
                              action="{{ route('produccion.destroy', $pd->cod_produccion) }}"
                              method="POST">
                              @csrf
                              @method('DELETE')
                              <button type='submit'
                                class="btn btn-danger mb-2">
                                <div
                                  class="w-4 mr-2 transform hover:text-red-500 hover:scale-110">
                                  <svg xmlns="http://www.w3.org/2000/svg"
                                    fill="none" viewBox="0 0 24 24"
                                    stroke="currentColor">
                                    <path stroke-linecap="round"
                                      stroke-linejoin="round" stroke-width="2"
                                      d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                  </svg>
                                </div>
                              </button>
                            </form>
                          @endif
                        </div>
                      </td>
                    </tr>
                  @endif
                @endforeach
              </tbody>
            </table>
          </div>

          <!-- Sección de Libros -->
          <div id="seccion-libro" style="display: none;">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
              {{ __('Producción de Libros') }}
            </h2>
            <table class="min-w-max w-full table-auto">
              <!-- Resto del código para la tabla de libros -->
              <thead>
                <tr
                  class="bg-gray-200 text-gray-600 uppercase text-sm leading-normal">
                  <th class="py-3 px-6 text-left">Titulo</th>
                  <th class="py-3 px-6 text-left">Nombre Libro</th>
                  <th class="py-3 px-6 text-left">Editorial</th>
                  <th class="py-3 px-6 text-left">Fecha de Publicacion </th>
                  <th class="py-3 px-6 text-left">ISBN</th>
                  <th class="py-3 px-6 text-left">Enlace</th>
                  <th class="py-3 px-6 text-center">Aciones</th>
                </tr>
              </thead>

              <tbody class="text-gray-600 text-sm font-light">
                @if (count($produccion->where('cod_tipo', 2)) == 0)
                  <tr class="border-b border-gray-200 hover:bg-gray-100">
                    <td class="py-3 px-6 text-left" colspan="7">
                      <div class="col-md-4 mx-auto">
                        <div class="card card-body text-center">
                          <p>No existen capacitaciones registradas</p>
                          <a class="text-green-600"
                            href="{{ route('produccion.create') }}">
                            Registrar un Libro
                          </a>
                        </div>
                      </div>
                    </td>
                  </tr>
                @endif

                @foreach ($produccion as $pd)
                  @if ($pd->cod_tipo == 2)
                    <tr class="border-b border-gray-200 hover:bg-gray-100">
                      <td class="py-3 px-6 text-left ">
                        <div class="flex items-center">
                          <span class="font-medium">{{ $pd->titulo }}</span>
                        </div>
                      <td class="py-3 px-6 text-left">
                        <div class="flex items-center">
                          <span>{{ $pd->nombre }}</span>
                        </div>
                      </td>
                      <td class="py-3 px-6 text-left">
                        <div class="flex items-center">
                          <span>{{ $pd->editorial }}</span>
                        </div>
                      </td>
                      <td class="py-3 px-6 text-left">
                        <div class="flex items-center">
                          <span>{{ $pd->fecha_publicacion_lib }}</span>
                        </div>
                      </td>
                      <td class="py-3 px-6 text-left">
                        <div class="flex items-center">
                          <span>{{ $pd->isbn }}</span>
                        </div>
                      </td>
                      <td class="py-3 px-6 text-left">
                        <div class="flex items-center">
                          <span>{{ $pd->enlace_lib }}</span>
                        </div>
                      </td>
                      <td class="py-3 px-6 text-center">
                        <div class="flex item-center justify-center">
                          <div
                            class="w-4 mr-2 transform hover:text-purple-500 hover:scale-110">
                            <a href="{{ route('produccion.show', $pd->cod_produccion) }}"
                              class="btn btn-secondary mb-2">
                              <svg xmlns="http://www.w3.org/2000/svg"
                                fill="none" viewBox="0 0 24 24"
                                stroke="currentColor">
                                <path stroke-linecap="round"
                                  stroke-linejoin="round" stroke-width="2"
                                  d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                <path stroke-linecap="round"
                                  stroke-linejoin="round" stroke-width="2"
                                  d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                              </svg>
                            </a>
                          </div>
                          @if (Auth::user()->cod_rol == 1)
                            <div
                              class="w-4 mr-2 transform hover:text-green-500 hover:scale-110">
                              <a href="{{ route('produccion.edit', $pd->cod_produccion) }}"
                                class="btn btn-secondary mb-2">
                                <svg xmlns="http://www.w3.org/2000/svg"
                                  fill="none" viewBox="0 0 24 24"
                                  stroke="currentColor">
                                  <path stroke-linecap="round"
                                    stroke-linejoin="round" stroke-width="2"
                                    d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                                </svg>
                              </a>
                            </div>
                            <form
                              action="{{ route('produccion.destroy', $pd->cod_produccion) }}"
                              method="POST">
                              @csrf
                              @method('DELETE')
                              <button type='submit'
                                class="btn btn-danger mb-2">
                                <div
                                  class="w-4 mr-2 transform hover:text-red-500 hover:scale-110">
                                  <svg xmlns="http://www.w3.org/2000/svg"
                                    fill="none" viewBox="0 0 24 24"
                                    stroke="currentColor">
                                    <path stroke-linecap="round"
                                      stroke-linejoin="round" stroke-width="2"
                                      d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                  </svg>
                                </div>
                              </button>
                            </form>
                          @endif
                        </div>
                      </td>
                    </tr>
                  @endif
                @endforeach
              </tbody>
            </table>
          </div>

          <!-- Sección de Ponencias -->
          <div id="seccion-ponencia" style="display: none;">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
              {{ __('Producción de Ponencias (Seminarios/Congresos)') }}
            </h2>
            <table class="min-w-max w-full table-auto">
              <!-- Resto del código para la tabla de ponencias -->
              <thead>
                <tr
                  class="bg-gray-200 text-gray-600 uppercase text-sm leading-normal">
                  <th class="py-3 px-6 text-left">Titulo</th>
                  <th class="py-3 px-6 text-left">Nombre Seminario/Congreso
                  </th>
                  <th class="py-3 px-6 text-left">País Evento</th>
                  <th class="py-3 px-6 text-left">Fecha del Evento </th>
                  <th class="py-3 px-6 text-left">Modalidad</th>
                  <th class="py-3 px-6 text-center">Aciones</th>
                </tr>
              </thead>

              <tbody class="text-gray-600 text-sm font-light">
                @if (count($produccion->where('cod_tipo', 3)) == 0)
                  <tr class="border-b border-gray-200 hover:bg-gray-100">
                    <td class="py-3 px-6 text-left" colspan="6">
                      <div class="col-md-4 mx-auto">
                        <div class="card card-body text-center">
                          <p>No existen capacitaciones registradas</p>
                          <a class="text-green-600"
                            href="{{ route('produccion.create') }}">
                            Registrar una Ponencia (Seminarios/Congresos)
                          </a>
                        </div>
                      </div>
                    </td>
                  </tr>
                @endif

                @foreach ($produccion as $pd)
                  @if ($pd->cod_tipo == 3)
                    <tr class="border-b border-gray-200 hover:bg-gray-100">
                      <td class="py-3 px-6 text-left ">
                        <div class="flex items-center">
                          <span class="font-medium">{{ $pd->titulo }}</span>
                        </div>
                      <td class="py-3 px-6 text-left">
                        <div class="flex items-center">
                          <span>{{ $pd->nombre }}</span>
                        </div>
                      </td>
                      <td class="py-3 px-6 text-left">
                        <div class="flex items-center">
                          <span>{{ $pd->pais_evento }}</span>
                        </div>
                      </td>
                      <td class="py-3 px-6 text-left">
                        <div class="flex items-center">
                          <span>{{ $pd->fecha_evento }}</span>
                        </div>
                      </td>
                      <td class="py-3 px-6 text-left">
                        <div class="flex items-center">
                          <span>{{ $pd->modalidad }}</span>
                        </div>
                      </td>
                      <td class="py-3 px-6 text-center">
                        <div class="flex item-center justify-center">
                          <div
                            class="w-4 mr-2 transform hover:text-purple-500 hover:scale-110">
                            <a href="{{ route('produccion.show', $pd->cod_produccion) }}"
                              class="btn btn-secondary mb-2">
                              <svg xmlns="http://www.w3.org/2000/svg"
                                fill="none" viewBox="0 0 24 24"
                                stroke="currentColor">
                                <path stroke-linecap="round"
                                  stroke-linejoin="round" stroke-width="2"
                                  d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                <path stroke-linecap="round"
                                  stroke-linejoin="round" stroke-width="2"
                                  d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                              </svg>
                            </a>
                          </div>
                          @if (Auth::user()->cod_rol == 1)
                            <div
                              class="w-4 mr-2 transform hover:text-green-500 hover:scale-110">
                              <a href="{{ route('produccion.edit', $pd->cod_produccion) }}"
                                class="btn btn-secondary mb-2">
                                <svg xmlns="http://www.w3.org/2000/svg"
                                  fill="none" viewBox="0 0 24 24"
                                  stroke="currentColor">
                                  <path stroke-linecap="round"
                                    stroke-linejoin="round" stroke-width="2"
                                    d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                                </svg>
                              </a>
                            </div>
                            <form
                              action="{{ route('produccion.destroy', $pd->cod_produccion) }}"
                              method="POST">
                              @csrf
                              @method('DELETE')
                              <button type='submit'
                                class="btn btn-danger mb-2">
                                <div
                                  class="w-4 mr-2 transform hover:text-red-500 hover:scale-110">
                                  <svg xmlns="http://www.w3.org/2000/svg"
                                    fill="none" viewBox="0 0 24 24"
                                    stroke="currentColor">
                                    <path stroke-linecap="round"
                                      stroke-linejoin="round" stroke-width="2"
                                      d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                  </svg>
                                </div>
                              </button>
                            </form>
                          @endif
                        </div>
                      </td>
                    </tr>
                  @endif
                @endforeach
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>

  <script>
    // Obtener elementos del DOM
    const navArticulo = document.getElementById('nav-articulo');
    const navLibro = document.getElementById('nav-libro');
    const navPonencia = document.getElementById('nav-ponencia');
    const seccionArticulo = document.getElementById('seccion-articulo');
    const seccionLibro = document.getElementById('seccion-libro');
    const seccionPonencia = document.getElementById('seccion-ponencia');

    // Manejar eventos de clic en las opciones del navbar

    navArticulo.addEventListener('click', function(event) {
      event
        .preventDefault(); // Evita que el enlace redirija a otra página si es necesario

      // Ocultar las otras secciones y mostrar la sección de Artículos
      seccionArticulo.style.display = 'block';
      seccionLibro.style.display = 'none';
      seccionPonencia.style.display = 'none';

      // Realizar otras acciones necesarias cuando se hace clic en la opción "Artículo" del navbar
    });

    navLibro.addEventListener('click', function(event) {
      event.preventDefault();

      // Ocultar las otras secciones y mostrar la sección de Libros
      seccionArticulo.style.display = 'none';
      seccionLibro.style.display = 'block';
      seccionPonencia.style.display = 'none';

      // Realizar otras acciones necesarias cuando se hace clic en la opción "Libro/Capítulo" del navbar
    });

    navPonencia.addEventListener('click', function(event) {
      event.preventDefault();

      // Ocultar las otras secciones y mostrar la sección de Ponencias
      seccionArticulo.style.display = 'none';
      seccionLibro.style.display = 'none';
      seccionPonencia.style.display = 'block';

      // Realizar otras acciones necesarias cuando se hace clic en la opción "Ponencia (Seminario/Congreso)" del navbar
    });
  </script>
</x-app-layout>
