<x-app-layout>
  <x-slot name="header">
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
      {{ __('Actualización de Producción Académica') }}
    </h2>
  </x-slot>
  <div class="py-12">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
      <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
        <div class="p-6 text-gray-900">
          <!-- component -->
          <!-- Regitro Periodo -->
          <form method="POST"
            action="{{ route('produccion.update', $produccion->cod_produccion) }}">
            @csrf
            @method('PUT')
            <!--Tipo Producciones Academicas-->
            <div>
              <h2 class="text-lg font-medium text-gray-900 mt-4">
                {{ __('Selecciona un tipo de producción:') }}
              </h2>
              <select id="cod_tipo" name="cod_tipo"
                value="{{ old('cod_tipo') ?? $produccion->cod_tipo }}">
                @foreach ($tipoProduccion as $tp)
                  <option class="mt-1 block w-full" value="{{ $tp->cod_tipo }}"
                    {{ $tp->cod_tipo == ($produccion->cod_tipo ?? '') ? 'selected' : '' }}>
                    {{ $tp->nombre }}
                  </option>
                @endforeach
              </select>
              <br />
            </div>

            <div class="lg:col-span-2">
              <br />
              <div
                class="grid gap-4 gap-y-2 text-sm grid-cols-1 md:grid-cols-3">
                <div class="md:col-span-1">
                  <x-input-label for="titulo" :value="__('Titulo')" />
                  <x-text-input id="titulo" name="titulo" type="text"
                    class="mt-1 block w-full"
                    value="{{ old('titulo') ?? $produccion->titulo }}" autofocus
                    autocomplete="titulo" />
                  <x-input-error class="mt-2" :messages="$errors->get('titulo')" />
                </div>

                <div class="md:col-span-1" data-tipo="1">
                  <x-input-label for="nombre" :value="__('Nombre Revista')" />
                  <x-text-input id="nombre" name="nombre" type="text"
                    class="mt-1 block w-full"
                    value="{{ old('nombre') ?? $produccion->nombre }}" autofocus
                    autocomplete="nombre" />
                  <x-input-error class="mt-2" :messages="$errors->get('nombre')" />
                </div>
                <div class="md:col-span-1" data-tipo="1">
                  <x-input-label for="pais_revista" :value="__('Pais Revista')" />
                  <x-text-input id="pais_revista" name="pais_revista"
                    type="text" class="mt-1 block w-full"
                    value="{{ old('pais_revista') ?? $produccion->pais_revista }}"
                    autofocus autocomplete="pais_revista" />
                  <x-input-error class="mt-2" :messages="$errors->get('pais_revista')" />
                </div>
                <div class="md:col-span-1" data-tipo="1">
                  <x-input-label for="fecha_publicacion_art"
                    :value="__('Fecha de Publicacion')" />
                  <x-text-input id="fecha_publicacion_art"
                    name="fecha_publicacion_art" type="date"
                    class="mt-1 block w-full"
                    value="{{ old('fecha_publicacion_art') ?? $produccion->fecha_publicacion_art }}"
                    autofocus autocomplete="fecha_publicacion_art" />
                  <x-input-error class="mt-2" :messages="$errors->get('fecha_publicacion_art')" />
                </div>
                <div class="md:col-span-1" data-tipo="1">
                  <x-input-label for="indexacion" :value="__('indexacion')" />
                  <x-text-input id="indexacion" name="indexacion" type="text"
                    class="mt-1 block w-full"
                    value="{{ old('indexacion') ?? $produccion->indexacion }}"
                    autofocus autocomplete="indexacion" />
                  <x-input-error class="mt-2" :messages="$errors->get('indexacion')" />
                </div>
                <div class="md:col-span-1" data-tipo="1">
                  <x-input-label for="issn" :value="__('ISSN')" />
                  <x-text-input id="issn" name="issn" type="text"
                    class="mt-1 block w-full"
                    value="{{ old('issn') ?? $produccion->issn }}" autofocus
                    autocomplete="issn" />
                  <x-input-error class="mt-2" :messages="$errors->get('issn')" />
                </div>
                <div class="md:col-span-1" data-tipo="1">
                  <x-input-label for="doi" :value="__('DOI')" />
                  <x-text-input id="doi" name="doi" type="text"
                    class="mt-1 block w-full" value="{{ $produccion->doi }}"
                    autofocus autocomplete="doi" readonly />
                  <x-input-error class="mt-2" :messages="$errors->get('doi')" />
                </div>

                <div class="md:col-span-1" data-tipo="1">
                  <x-input-label for="enlace_art" :value="__('Enlace')" />
                  <x-text-input id="enlace_art" name="enlace_art" type="text"
                    class="mt-1 block w-full"
                    value="{{ old('enlace_art') ?? $produccion->enlace_art }}"
                    autofocus autocomplete="enlace_art" />
                  <x-input-error class="mt-2" :messages="$errors->get('enlace_art')" />
                </div>


                <div class="md:col-span-1" data-tipo="2">
                  <x-input-label for="nombre" :value="__('Nombre Libro')" />
                  <x-text-input id="nombre" name="nombre" type="text"
                    class="mt-1 block w-full"
                    value="{{ old('nombre') ?? $produccion->nombre }}"
                    autofocus autocomplete="nombre" />
                  <x-input-error class="mt-2" :messages="$errors->get('nombre')" />
                </div>
                <div class="md:col-span-1" data-tipo="2">
                  <x-input-label for="editorial" :value="__('Editorial')" />
                  <x-text-input id="editorial" name="editorial"
                    type="text" class="mt-1 block w-full" :
                    value="{{ old('editorial') ?? $produccion->editorial }}"
                    autofocus autocomplete="editorial" />
                  <x-input-error class="mt-2" :messages="$errors->get('editorial')" />
                </div>
                <div class="md:col-span-1" data-tipo="2">
                  <x-input-label for="fecha_publicacion_lib"
                    :value="__('Fecha de Publicacion')" />
                  <x-text-input id="fecha_publicacion_lib"
                    name="fecha_publicacion_lib" type="date"
                    class="mt-1 block w-full"
                    value="{{ old('fecha_publicacion_lib') ?? $produccion->fecha_publicacion_lib }}"
                    autofocus autocomplete="fecha_publicacion_lib" />
                  <x-input-error class="mt-2" :messages="$errors->get('fecha_publicacion_lib')" />
                </div>
                <div class="md:col-span-1" data-tipo="2">
                  <x-input-label for="isbn" :value="__('ISBN')" />
                  <x-text-input id="isbn" name="isbn" type="text"
                    class="mt-1 block w-full"
                    value="{{ old('isbn') ?? $produccion->isbn }}" autofocus
                    autocomplete="isbn" />
                  <x-input-error class="mt-2" :messages="$errors->get('isbn')" />
                </div>
                <div class="md:col-span-1" data-tipo="2">
                  <x-input-label for="enlace_lib" :value="__('Enlace')" />
                  <x-text-input id="enlace_lib" name="enlace_lib"
                    type="text" class="mt-1 block w-full"
                    value="{{ old('enlace_lib') ?? $produccion->enlace_lib }}"
                    autofocus autocomplete="enlace_lib" />
                  <x-input-error class="mt-2" :messages="$errors->get('enlace_lib')" />
                </div>


                <div class="md:col-span-1" data-tipo="3">
                  <x-input-label for="nombre" :value="__('Nombre Seminario/Congreso')" />
                  <x-text-input id="nombre" name="nombre_revista"
                    type="text" class="mt-1 block w-full"
                    value="{{ old('nombre') ?? $produccion->nombre }}"
                    autofocus autocomplete="nombre" />
                  <x-input-error class="mt-2" :messages="$errors->get('nombre')" />
                </div>
                <div class="md:col-span-1" data-tipo="3">
                  <x-input-label for="pais_evento" :value="__('Pais del Evento')" />
                  <x-text-input id="pais_evento" name="pais_evento"
                    type="text" class="mt-1 block w-full"
                    value="{{ old('pais_evento') ?? $produccion->pais_evento }}"
                    autofocus autocomplete="pais_evento" />
                  <x-input-error class="mt-2" :messages="$errors->get('pais_evento')" />
                </div>
                <div class="md:col-span-1" data-tipo="3">
                  <x-input-label for="fecha_evento" :value="__('Fecha del Evento')" />
                  <x-text-input id="fecha_evento" name="fecha_evento"
                    type="date" class="mt-1 block w-full"
                    value="{{ old('fecha_evento') ?? $produccion->fecha_evento }}"
                    autofocus autocomplete="fecha_evento" />
                  <x-input-error class="mt-2" :messages="$errors->get('fecha_evento')" />
                </div>
                <div class="md:col-span-1" data-tipo="3">
                  <x-input-label for="modalidad" :value="__('Modalidad')" />
                  <x-text-input id="modalidad" name="modalidad"
                    type="text" class="mt-1 block w-full"
                    value="{{ old('modalidad') ?? $produccion->modalidad }}"
                    autofocus autocomplete="modalidad" />
                  <x-input-error class="mt-2" :messages="$errors->get('modalidad')" />
                </div>
                <!---

                              <div class="md:col-span-1">
                                  <x-input-label for="sjr" :value="__('SJR')" />
                                  <x-text-input id="sjr" name="sjr" type="text"
                                      class="mt-1 block w-full" :value="old('sjr')" autofocus autocomplete="sjr" />
                                  <x-input-error class="mt-2" :messages="$errors->get('sjr')" />
                              </div>
                              <div class="md:col-span-1">
                                  <x-input-label for="jcr" :value="__('JCR')" />
                                  <x-text-input id="jcr" name="jcr" type="text"
                                      class="mt-1 block w-full" :value="old('jcr')" autofocus autocomplete="jcr" />
                                  <x-input-error class="mt-2" :messages="$errors->get('jcr')" />
                              </div>
                              <div class="md:col-span-1">
                                  <x-input-label for="otro_repositorio" :value="__('Otros Repositorios')" />
                                  <x-text-input id="otro_repositorio" name="otro_repositorio" type="text"
                                      class="mt-1 block w-full" :value="old('otro_repositorio')" autofocus
                                      autocomplete="otro_repositorio" />
                                  <x-input-error class="mt-2" :messages="$errors->get('otro_repositorio')" />
                              </div>
                              --->

              </div>
            </div>
            {{-- Nombre del repositorio  --}}

            <div class="grid gap-4 gap-y-2 text-sm grid-cols-1 lg:grid-cols-3"
              data-tipo="1">
              <h2 class="text-lg font-medium text-gray-900 mt-4">
                {{ __('Nombre del repositorio') }}
              </h2>
              <select id="cod_repositorio_art" name="cod_repositorio_art">
                @foreach ($repositorioArt as $repo)
                  <option value="{{ $repo->cod_repositorio_art }}"
                    @if (
                        $produccion->repositorioArt &&
                            $produccion->repositorioArt->cod_repositorio_art ==
                                $repo->cod_repositorio_art) selected @endif>
                    {{ $repo->nombre }}
                  </option>
                @endforeach
              </select>
            </div>
            <br />
            <div class="md:col-span-5 text-right">
              <x-primary-button class="ml-4">
                <input class="btn btn-secondary mb-2" value="Registrar"
                  type="submit">
              </x-primary-button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</x-app-layout>
<!-- Scripts -->
<script>
  function handleTipoChange() {
    var selectedValue = document.getElementById('cod_tipo').value;
    var elementos = document.querySelectorAll('[data-tipo]');

    elementos.forEach(function(elemento) {
      if (elemento.getAttribute('data-tipo') === selectedValue ||
        selectedValue === '0') {
        elemento.style.display = 'block';
      } else {
        elemento.style.display = 'none';
      }
    });
  }

  document.addEventListener('DOMContentLoaded', function() {
    handleTipoChange
      (); // Llamar a la función cuando la página se haya cargado completamente

    document.getElementById('cod_tipo').addEventListener('change',
      handleTipoChange);
  });
</script>
