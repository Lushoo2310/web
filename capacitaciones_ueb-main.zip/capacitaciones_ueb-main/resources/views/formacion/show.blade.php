<x-app-layout>
  <div class="py-6">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
      <div class="bg-white overflow-hidden shadow-sm rounded-lg">
        <div class="p-6 text-gray-900">

          <!-- Título -->
          <h3 class="text-lg font-medium leading-6 text-gray-900 mb-4">
            Formación Registrada
          </h3>

          <!-- Detalles del formación -->
          <div class="bg-gray-50 shadow rounded-md mb-4 p-4">
            <dl
              class="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6 text-sm sm:text-base">
              <div class="sm:col-span-1">
                <dt class="font-medium text-gray-500">
                  Número de registro en la senescyt
                </dt>
                <dd class="mt-1 text-gray-900">
                  {{ $formacion->registro }}
                </dd>
              </div>
              <div class="sm:col-span-1">
                <dt class="font-medium text-gray-500">
                  Tipo de Formación Académica
                </dt>
                <dd class="mt-1 text-gray-900">
                  {{ $formacion->tipoFormacion->nombre }}
                </dd>
              </div>
              <div class="sm:col-span-1">
                <dt class="font-medium text-gray-500">
                  Nombre de Usuario
                </dt>
                <dd class="mt-1 text-gray-900">
                  {{ $formacion->cod_user }}
                </dd>
              </div>
            </dl>
          </div>

          <!-- Botones de acción -->
          <div class="flex justify-end">
            <div class="mr-4">
              <x-secondary-button>
                <a
                  href="{{ route('formacion.edit', $formacion->cod_formacion) }}">
                  Editar Periodo
                </a>
              </x-secondary-button>
            </div>
            <form
              action="{{ route('formacion.destroy', $formacion->cod_formacion) }}"
              method="POST">
              @csrf
              @method('DELETE')
              <x-danger-button type="submit">
                Eliminar Periodo
              </x-danger-button>
            </form>
          </div>

        </div>
      </div>
    </div>
  </div>
</x-app-layout>
