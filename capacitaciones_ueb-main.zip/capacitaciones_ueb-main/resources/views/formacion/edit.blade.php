<x-app-layout>
  <x-slot name="header">
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
      {{ __('Actualización de Formación Académica') }}
    </h2>
  </x-slot>

  <div class="py-12">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
      <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
        <div class="p-6 text-gray-900">
          <!-- Registro de Formación Académica -->

          <div class="grid gap-4 md:gap-8 grid-cols-1 lg:grid-cols-2">
            <form method="POST"
              action="{{ route('formacion.update', $formacion->cod_formacion) }}">
              @csrf
              @method('PUT')
              <h2 class="text-lg font-medium text-gray-900">
                {{ __('Formación Académica') }}
              </h2>

              <div class="grid grid-cols-1 md:grid-cols-5 gap-4 md:gap-8">
                <div class="md:col-span-5">
                  <x-input-label for="registro" :value="__('Número de registro')" />
                  <x-text-input id="registro" name="registro" type="text"
                    class="mt-1 block w-full"
                    value="{{ old('registro') ?? $formacion->registro }}"
                    required autofocus autocomplete="registro" />
                  <x-input-error class="mt-2" :messages="$errors->get('registro')" />
                </div>
              </div>

              <!--Tipo de Periodo Académico-->
              <h2 class="text-lg font-medium text-gray-900 mt-8">
                {{ __('Tipo de Formación Académica') }}
              </h2>

              <div class="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-8">
                @foreach ($tipoFormacion as $tf)
                  <div class="md:col-span-1">
                    <label class="inline-flex items-center cursor-pointer">
                      <input
                        {{ $formacion->TipoFormacion->cod_tipo == $tf->cod_tipo ? 'checked' : '' }}
                        type="radio"
                        class="form-radio h-4 w-4 text-indigo-600 transition duration-150 ease-in-out"
                        name="cod_tipo"
                        value="{{ old('cod_tipo') ?? $tf->cod_tipo }}" />
                      <span
                        class="ml-2">{{ old('nombre') ?? $tf->nombre }}</span>
                    </label>
                  </div>
                @endforeach
              </div>

              <div class="mt-8 text-right">
                <x-primary-button>
                  <input class="btn btn-secondary mb-2"
                    value="{{ __('Registrar') }}" type="submit">
                </x-primary-button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</x-app-layout>
